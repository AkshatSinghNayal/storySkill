#!/usr/bin/env python3
"""Audit a production prompt's narration, delivery manifest, and estimated runtime.

Standard library only. No synthesis, network, or output files. A passing audit
does not establish joke quality, speech alignment, or measured video duration.
"""

import argparse
import json
import math
from pathlib import Path
import re
import sys


WORD = re.compile(r"[^\W\d_]+(?:['’][^\W\d_]+)*")
SEGMENT = re.compile(r"N\d{3}")


def audit(text, *, target=90, ceiling=179, lead=0.25, tail=0.25,
          extra_hold=0, rates=(145, 165, 185)):
    errors, warnings = [], []
    result = {"timing_status": "estimated, not synthesized or measured",
              "errors": errors, "warnings": warnings}
    settings = (target, ceiling, lead, tail, extra_hold, *rates)
    if not all(math.isfinite(v) for v in settings):
        errors.append("Timing parameters must be finite numbers.")
        return result
    if not 0 < target <= ceiling < 180:
        errors.append("Require 0 < target <= maximum < 180 seconds.")
    if min(lead, tail, extra_hold) < 0:
        errors.append("Lead, tail, and extra holds cannot be negative.")
    if len(rates) != 3 or any(v <= 0 for v in rates) or list(rates) != sorted(rates):
        errors.append("Provide three positive baseline WPM rates in ascending order.")
    starts = list(re.finditer(r"(?m)^[ \t]*BEGIN_NARRATION[ \t]*\r?$", text))
    ends = list(re.finditer(r"(?m)^[ \t]*END_NARRATION[ \t]*\r?$", text))
    if len(starts) != 1 or len(ends) != 1 or starts[0].end() >= ends[0].start():
        errors.append("Require exactly one ordered BEGIN_NARRATION/END_NARRATION block.")
        return result
    narration = text[starts[0].end():ends[0].start()].strip()
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", narration) if p.strip()]
    if not paragraphs:
        errors.append("Narration is empty.")
        return result
    expected = [f"N{i:03d}" for i in range(1, len(paragraphs) + 1)]
    counts = [len(WORD.findall(p)) for p in paragraphs]
    if any(n == 0 for n in counts):
        errors.append("Every narration paragraph needs spoken English words.")
    if re.search(r"\d|[$%]|\b[A-Z]{2,}\b", narration):
        warnings.append("Narration contains digits, symbols, or all-caps tokens; "
                        "verify their spoken expansion before trusting the count.")
    if re.search(r"(?m)^\s*(?:#{1,6}\s|\||N\d{3}\b|```|\[)", narration):
        errors.append("Narration appears to contain headings, IDs, or production markup.")

    # Only delivery rows have a paragraph ID in the first column. Scene tables
    # use scene IDs, and short trigger quotes are excluded from the word count.
    outside = text[:starts[0].start()] + text[ends[0].end():]
    rows = []
    for line in outside.splitlines():
        if not line.strip().startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if not cells or not SEGMENT.fullmatch(cells[0]):
            continue
        if len(cells) != 4:
            errors.append(f"Delivery row {cells[0]} needs exactly four columns.")
            continue
        segment, speed_text, pause_text, delivery = cells
        try:
            speed, pause = float(speed_text), float(pause_text)
        except ValueError:
            errors.append(f"{segment}: speed and pause must be numeric.")
            continue
        if not math.isfinite(speed) or not math.isfinite(pause) or speed <= 0 or pause < 0:
            errors.append(f"{segment}: require finite positive speed and nonnegative pause.")
            continue
        if not delivery:
            errors.append(f"{segment}: delivery note is empty.")
        if not 0.85 <= speed <= 1.15:
            warnings.append(f"{segment}: speed {speed:g} needs an actual listening check.")
        rows.append({"segment": segment, "speed": speed, "pause": pause})
    actual = [r["segment"] for r in rows]
    if actual != expected:
        errors.append("Delivery IDs must cover every paragraph exactly once, in order: "
                      + ", ".join(expected))
        result["found_delivery_ids"] = actual
    result.update({"spoken_words": sum(counts), "paragraphs": len(paragraphs),
                   "segment_word_counts": dict(zip(expected, counts))})
    if errors:
        return result

    pauses = sum(r["pause"] for r in rows)
    non_speech = pauses + lead + tail + extra_hold
    effective_words = sum(n / r["speed"] for n, r in zip(counts, rows))
    estimates = {str(rate): round(effective_words * 60 / rate + non_speech, 2)
                 for rate in rates}
    slow, central, fast = [effective_words * 60 / rate + non_speech for rate in rates]
    result.update({"boundary_pause_seconds": round(pauses, 3),
                   "lead_seconds": lead, "tail_seconds": tail,
                   "extra_nonoverlapping_hold_seconds": extra_hold,
                   "target_seconds": target, "maximum_seconds": ceiling,
                   "estimates_by_baseline_wpm": estimates,
                   "estimated_range_seconds": [round(fast, 2), round(slow, 2)],
                   "central_estimate_seconds": round(central, 2)})
    if fast > ceiling:
        errors.append("Even the fastest planning estimate exceeds the maximum. "
                      "Revise the original script or resolve a locked-script conflict.")
    elif slow > ceiling:
        warnings.append("The slower planning estimate exceeds the maximum; leave "
                        "more headroom and measure real narration before rendering.")
    if central > target:
        warnings.append("The central estimate exceeds the stated target; revise the "
                        "target or script instead of silently speeding up narration.")
    if slow < target * 0.65:
        warnings.append("The script is much shorter than the target at these rates; "
                        "prefer an honest shorter duration to filler or static holds.")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("prompt", type=Path)
    parser.add_argument("--target-seconds", type=float, default=90)
    parser.add_argument("--max-seconds", type=float, default=179)
    parser.add_argument("--lead", type=float, default=0.25)
    parser.add_argument("--tail", type=float, default=0.25)
    parser.add_argument("--extra-hold", type=float, default=0)
    parser.add_argument("--wpm", nargs=3, type=float, default=(145, 165, 185),
                        metavar=("SLOW", "CENTRAL", "FAST"))
    args = parser.parse_args()
    try:
        result = audit(args.prompt.read_text(encoding="utf-8"),
                       target=args.target_seconds, ceiling=args.max_seconds,
                       lead=args.lead, tail=args.tail, extra_hold=args.extra_hold,
                       rates=args.wpm)
    except (OSError, UnicodeError) as exc:
        print(json.dumps({"errors": [str(exc)]}, indent=2))
        return 2
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 1 if result["errors"] else 0


if __name__ == "__main__":
    sys.exit(main())
