# Example 04 — Final Sale

Craft calibration only: this older compact script format is not the current complete deliverable. Follow [the production prompt contract](../references/production-prompt.md) for full output and timing; the example timings below are illustrative, not measured audio.

## Generic version — rejected

Derek arrived at an afterlife office and complained about the service. The clerk found out he had treated his own customers badly. Derek was assigned to answer complaints forever. He discovered the chair was uncomfortable and finally understood how his customers had felt. The lesson was to be nicer.

Why it fails: generic cosmic punishment, a moral that explains, no early prop, no exact rule creating the consequence, and a random uncomfortable chair instead of a causal second hit.

## Sharper version

**Title:** He Brought His Refund Policy Upstairs

**Hook:** The afterlife offers Derek perfect continuity of service.

**Blueprint:** Afterlife Bureaucracy — intake adopts the owner's own rules literally.

**Intensity:** 3; one implied, unintended offscreen mishap, no injury depiction or realistic distress audio.

**Vocabulary world:** Customer support.

**Assumptions:** US adults; 75 seconds to allow a clear cutaway and unhurried policy setup; Derek Sullivan; entirely imaginary afterlife service. Previous protagonist: Maya. Current cold motive: uselessly literal policy application.

**Logline:** He demanded that the afterlife use his own no-refunds, owner-handles-complaints policy, so becoming its nonreturnable complaint handler was the only possible result.

**Plant/payoff:** FINAL SALE badge spoken at 0–10s; it returns at 70–75s as Derek's status rather than his sales slogan. Final spoken callback: "And FINAL SALE finally described the salesman."

### MATH CHECK

All afterlife charges are conspicuously fictional satire, not a claim about debt after death or any religion. The arithmetic uses ordinary US support-fee magnitudes. The fee is established before it applies to Derek; no tax, interest, or refunds.

| figure | formula | result |
| --- | --- | --- |
| Support fee | Given fictional business rule | $5.00/call |
| Chargeable requests | 1 chair call + 1 break call + 1 supervisor call | 3 calls |
| Total charges | $5.00 × 3 | $15.00 |
| Refund under copied rule | Given fictional no-refunds policy | $0.00 |
| Net charge | $15.00 − $0.00 | $15.00 |
| Runtime | 10 + 20 + 20 + 20 + 5 seconds | 75 seconds |

### Script

| TIME | NARRATION | CARD TEXT | FACE / ANIMATION | SFX |
| --- | --- | --- | --- | --- |
| 0–10s — Lazy Goal | Derek demanded afterlife service on his terms. His old customer-service badge still said FINAL SALE. | FICTIONAL AFTERLIFE; INTAKE: BRING YOUR OWN POLICY | Already at an impossible, illustrated service counter; badge readable. No body, injury, or religious symbols. | Soft startup chime after "FINAL SALE." |
| 10–30s — Smug Phase | Earlier, he'd rushed installation of a giant statue of himself. The safety review was taking attention away from the unveiling. Now, at the afterlife desk, he supplied his rules: no refunds, complaints handled by the owner, five dollars per support call. | Before cut: SELF-COMMISSIONED TRIBUTE. After cut: LEGACY POLICY IMPORT | Brief abstract flashback: statue silhouette and ceremonial curtain only. Cut to black before any movement or impact, after "unveiling." Return to intact afterlife avatar with smug squint. | During a 0.3s narration pause on black: one soft cartoon bonk, then silence. No scream or realistic impact. |
| 30–50s — Cold Escalation | The clerk asked whether he was the owner. Derek nodded. He requested the executive package. The clerk selected COPY EARTH SETTINGS. Derek liked that. His ego had opened a support ticket with no other department. | POLICY OWNER: DEREK SULLIVAN; ESCALATION PATH: SAME OWNER | Clerk politely imports the policies; Derek straightens his badge. | One mouse click after "COPY EARTH SETTINGS." |
| 50–70s — Panic + Double-Tap | He received an eternal complaint queue and no refunds. He called to request a chair, a break, and a supervisor. His own five-dollar fee applied to all three calls. | After fee lands: FICTIONAL RECEIPT; $5.00 × 3 calls = $15.00 | Main consequence lands; 0.5s silence after "no refunds." Bug-eyed panic becomes hollow stare while calls loop back to his desk. Hold receipt for 4s. | Dry stamp after "three calls"; silence through the double-tap gap. |
| 70–75s — Sarcastic Moral | And FINAL SALE finally described the salesman. | RETURN WINDOW: CLOSED BY OWNER | Tight, readable badge close-up; no extra visual punchline. | None. |

**Final spoken moral:** And FINAL SALE finally described the salesman.

**Alternative titles:** "His Own Refund Policy Followed Him Upstairs"; "The Afterlife Copied His Customer Service"; "He Became the Entire Complaints Department."

**Opening text:** SAME OWNER. SAME TERMS.

**Description:** Original fictional afterlife comedy about a customer-service owner trapped by his own policies. Contains a brief cartoon cutaway; all people, documents, and fees are invented.

**Tags:** dark comedy, afterlife satire, customer service comedy, fictional story.

### Checklist notes

PASS: seven-word premise; badge planted audibly in the first 10s and returned in the last five. Derek's impatience causes the implied mishap, and his demand to copy his own rules causes every administrative consequence. No mechanism, visible impact, injury, self-harm, or real tragedy appears. The fantastical policy loop is the subject; the cutaway is brief context.

The main hit is the nonreturnable complaint assignment; the $15.00 fee to ask for ordinary workplace comforts is pettier and comes from the already-stated rule. Fresh metaphor: ego opening a support ticket with no other department. Cards add ownership and routing information; the best joke is the spoken badge callback. Derek follows Maya; literal application replaces the boss's selfish motive. One vocabulary world, US names/currency, title limits, and originality pass.

Math: $5.00 × 3 = $15.00; no extra charge is hidden. Intensity/content gates pass for this skill's Level 3, while actual advertiser suitability remains subject to the full production and platform review. For an advertiser-priority variant, omit the flashback and begin with the already-arrived avatar; the administrative story remains intact.

**Editorial score:** 9/10 — causality 2, freshness 1, callback 2, double-tap 2, production clarity 2.

**Production note:** 129 spoken words, expanding hyphenated compounds; estimated 75s at approximately 130 words/minute plus holds, with the opening sentence at 150 words/minute to land within three seconds. Includes a 0.3s black-screen pause for the stylized cue and 0.5s between assignment and petty fee. No recorded read has been measured. Verify current prices, rules, and YouTube policies before publishing.
