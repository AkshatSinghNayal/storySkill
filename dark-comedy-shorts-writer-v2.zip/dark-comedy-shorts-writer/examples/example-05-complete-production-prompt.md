# Complete production prompt — calibration example

This expands Example 02 into the new output format. It demonstrates a self-contained handoff, not a fresh premise to reuse in future requests. The story and render below have not been synthesized or produced. Reference guides describe the general rules; the prompt contains concrete choices for this film.

```text
# PROJECT: HIS CROWN VIOLATED HIS OWN RULES

## 1. OBJECTIVE AND CREATIVE DECISIONS
Create an original fictional animated adult comedy about Greg, an HOA president whose no-exceptions decoration policy applies to his own ceremonial crown and lawn throne. Use the installed faceless-shorts skill. The audience is US adults and international English speakers. Tone: exhausted, dry, observant; the target is Greg's self-exemption, not his age or an identity group. Intensity: Level 2, entirely nonviolent.

Use one third-person American male narrator. Greg is the flawed actor; the compliance clerk simply follows his published rules. The figurative world is petty neighborhood government. Plant the gold crown in the opening; end with its authority reduced to indoor furniture. The main consequence is a fictional fine, followed by the pettier request for a bag-color sample. The final spoken callback is N012; nothing is spoken after it.

Visual type: Tall Tale's expressive 2D cutout adults in a sunny 3D neighborhood. These are not fully modeled 3D humans. Plan approximately one minute, subject to the measured-audio budget below. This project's hard ceiling is 75 seconds; never stretch it with filler. Preserve the visual type. If necessary, reduce output to 720×1280 or use 24 fps and disclose the actual settings; do not silently switch to a flat slideshow.

## 2. EXACT NARRATION — ONLY THIS BLOCK GOES TO TTS
Preserve every spoken word below. Blank-line-separated paragraphs map to N001 through N012 in order. Do not synthesize the markers, IDs, production notes, cards, or metadata. All quoted dialogue uses the same narrator.

BEGIN_NARRATION
Greg banned ugly decorations from the neighborhood.

He announced this wearing a gold plastic crown. Apparently, bad taste was fine if it chaired the meeting.

His rules were simple. Outdoor decorations needed approval. Each unapproved item cost twenty-five dollars a day. No exceptions.

Then he put a throne on his lawn. It was a patio chair with ambition.

The compliance clerk asked for his approval forms.

"I submitted them," Greg said. He had rejected them himself without reading. He thought paperwork was for the neighbors.

The clerk listed two decorations: crown and throne.

Greg appealed for four days. He kept displaying both while he waited. Taking them inside would look like surrender.

The clerk called that two hundred dollars.

Greg covered his crown with a trash bag. Finally, something tasteful.

The clerk asked for a bag-color sample.

And his crown retained full authority over the couch.
END_NARRATION

## 3. SKILL COMPATIBILITY AND SCOPE
Read the installed faceless-shorts skill and Tall Tale documentation; inspect the actual narration, alignment, caption, mixer, and capture interfaces. Reuse the existing project layout, Toon characters, 3D world/interior pieces, and capture utilities. This is explicitly fiction; do not replace it with a historical true story or the source example's 40–60-second plot. Do not rewrite the approved story to match an unrelated example.

Create a separate project. Small additions: a gold plastic crown attached to Greg's head, the same crown concealed by a loose cartoon bag, a dressed patio chair, a generic fictional HOA notice, and a color-sample overlay. Reuse the generic house/interior and paper/stamp primitives where available. No new engine, paid APIs, uploads, or public file hosting.

The story and plan are already supplied. Continue through the complete render and verification, without stopping to ask whether to build the storyboard. Report an actual blocking capability problem honestly if one remains after bounded diagnosis.

## 4. CAST, SETS, AND CONTINUITY
GREG: fictional adult, 48, square orange glasses, short brown hair, navy polo, tan pants, slightly forward chin. His gold crown is deliberately cheap plastic. He begins with a smug half-smile; his expressions progress through dismissive certainty, insulted disbelief, brittle optimism, then a hollow stare. Use supported Toon mood/look/arm controls; the crown is a small prop extension, not a new character system.

CLERK: fictional adult, 36, short dark hair, muted green jacket, gray pants, cream clipboard. Calm, practical posture. The clerk has no malicious grin and does not celebrate the fine. One tiny eyebrow raise is enough. No extra clerk voice or lip-sync.

CROWN: one gold five-point plastic crown with a small visible seam. Never change its color or shape. It remains on Greg's head outdoors, is concealed only during N010–N011, and reappears uncovered indoors for N012.

THRONE: one ordinary white patio chair with a purple cushion. It remains outdoors throughout the four fictional appeal days, then moves inside with Greg at the ending. Do not confuse it with the separate beige couch.

YARD: a sunny miniature suburban front lawn. House door screen-left, path screen-right, throne near center. Clipboard and card inserts use the upper-left empty sky area. No real HOA logo, street address, or government seal.

LIVING ROOM: the matching house interior, beige couch behind the relocated patio chair. Ending light is warm, with no crowd. The clerk never enters this room.

## 5. VOICE AND DELIVERY MANIFEST
Preferred voice: am_michael, one identity throughout. General baseline speed: 1.00. Use the installed backend's American English syntax; the reviewed kokoro-onnx wrapper used en-us, so do not blindly pass the code a. No unsupported emotion parameters. Narrate like a neighbor describing an entirely avoidable meeting.

Implement these modest per-paragraph speed changes through a compatible segment adapter if the original wrapper supports only global speed. Otherwise disclose one global speed and preserve the important pause boundaries. Generate natural connected sentences, then check the joins by listening.

| Segment | Speed | Pause after (s) | Delivery |
| --- | --- | --- | --- |
| N001 | 1.03 | 0.15 | State the premise plainly; no dramatic announcer voice. |
| N002 | 1.00 | 0.25 | Treat the crown as routine; let the final clause fall. |
| N003 | 1.03 | 0.30 | Clear policy rhythm; a slight settling emphasis on exceptions. |
| N004 | 1.00 | 0.30 | Ordinary description first, completely straight comparison second. |
| N005 | 1.02 | 0.15 | Practical question, without playing a separate clerk voice. |
| N006 | 1.03 | 0.25 | Brief confidence in the quote; dry explanation afterward. |
| N007 | 0.99 | 0.25 | Let the two-item classification register. |
| N008 | 1.03 | 0.20 | His refusal sounds sincerely important to him. |
| N009 | 0.98 | 0.50 | State the total clearly, then full comic silence. |
| N010 | 1.00 | 0.30 | Matter-of-fact physical solution; flat final observation. |
| N011 | 0.98 | 0.40 | Clerical normality, no wink or emphasis on absurdity. |
| N012 | 0.97 | 0.00 | Quiet final verdict; end cleanly with no extra moral. |

These are target total boundary silences. Account for any silence already in the generated segment. The N009 face hold and audio gap are the same 0.50 seconds, not two separate pauses. Do not put musical or effect sounds in that gap.

## 6. RUNTIME AND MEASUREMENT
Count only the canonical narration. Planning lead: 0.25 seconds. Tail after the final spoken word: 0.25 seconds. Total manifest silence: 3.05 seconds. No additional nonoverlapping holds; cards persist during speech where needed.

Estimate using sum(segment words × 60 / (baseline WPM × suggested speed)) plus 3.55 seconds for silence, lead, and tail. Use 145/165/185 WPM as slow/central/fast assumptions, not benchmarks. The canonical narration contains 148 spoken words in 12 paragraphs. With the listed speed suggestions, the estimates are 64.23 seconds at 145 WPM, 56.88 at 165 WPM, and 51.11 at 185 WPM. Plan about 51–65 seconds, with a central estimate of 57 seconds; none is a measured audio duration.

Measure the combined narration before constructing the final timeline. Keep the crown introduction within the opening 10 seconds and N012 within the closing 10. If the actual read exceeds 75 seconds at natural delivery, report that constraint before expensive rendering; do not omit words or rush the punchlines. A shorter successful read does not need padding to reach a minute.

## 7. COMPLETE SCENE DIRECTION
All segments play once, in order. Internal shots share continuous audio rather than replaying their assigned segment. Use word/phrase anchors within the specified paragraph, not fabricated exact timestamps.

S01 — N001–N002, the neighborhood monarch.
Open on Greg addressing an empty patch of lawn, framed waist-up; keep his head just outside the initial crop. On N002's word crown, gently widen to reveal the cheap crown. His right hand makes a small official wave. On chaired the meeting, settle into a smug squint for the already-budgeted boundary pause. No card or opening title slate. Do not reveal the later fine or throne. Transition with a clipboard entering foreground from the clerk's side.

S02 — N003, rules with no escape clause.
Over-shoulder insert of Greg pointing at three short lines on a clearly fictional notice: APPROVAL REQUIRED; $25.00 / ITEM / DAY; NO EXCEPTIONS. Reveal each line after its corresponding spoken statement, not all at once. Return to Greg on exceptions; he taps the crown as if this resolves jurisdiction. C01 appears in the open sky after that word and remains into the start of S03 for 1.8 seconds. No page of fine print.

S03 — N004, the throne.
Wide lawn view. Greg drags the ordinary patio chair from the doorway with both hands; movement ends before he sits. On throne, settle him onto the purple cushion. On ambition, show a low, excessively respectful camera angle on the visibly ordinary chair. His feet do not intersect the ground. Clear C01 without a second card. One soft plastic-chair creak can follow the comparison; omit it if unavailable.

S04 — N005–N006, his own rejection.
The clerk enters screen-right and holds out the clipboard without taking Greg's crown. On forms, show the generic application, initially folded. Greg points at his own signature during I submitted them. On rejected them himself, unfold to show a REJECTED stamp and the same signature. Only then display C02 for 2.5 seconds through the next neutral phrase. Greg looks from signature to crown, keeping a stubborn smile. One soft stamp after the spoken reveal; not on top of it.

S05 — N007–N008, four days of dignity.
The clerk ticks two boxes in sequence on crown and throne; the items stay physically in place. C03 appears after the classification for 1.8 seconds. During N008, show four brief daylight-to-evening transitions, each ending with Greg outside in the crown and chair. This symbolizes four complete counted display days; do not imply a new daily fee per appeal. An APPEAL SENT paper moves from Greg's hand into a generic mailbox, never floating ahead of it. Clear overlays before the bill. On surrender, his jaw sets with exaggerated determination; no new sound.

S06 — N009, the actual total.
Hold a medium two-shot. The clerk turns the fictional notice toward Greg after the full spoken amount. Display C04 with its readable calculation for 3.5 seconds, overlapping the beginning of S07; do not add that hold to the audio duration. Greg's eyes move to the total, widen, then freeze during the manifest's 0.50-second silence. Stop music before the amount and keep effects off through the silence. Do not show the total early.

S07 — N010–N011, an application for a trash bag.
Greg takes a loose gray cartoon bag from beside the chair and places it over the crown only, leaving his entire face unobstructed. The bag covers the headwear, not his breathing or body. On tasteful, he makes one proud open-palm gesture. C04 clears after its scheduled hold; no other card replaces it. On N011's sample, the clerk quietly extends a small blank swatch form. Greg looks at the form, then at the bag, then at the camera. His smile slowly collapses into a tired stare. No loud sting, additional charge, or invented fourth rule. Hold the existing 0.40-second boundary silence, then cut indoors.

S08 — N012, reduced jurisdiction.
Greg sits on the same patio chair, now indoors beside the beige couch; crown uncovered. He solemnly gestures at the couch as if presiding over it. Use a slow modest push toward the crown and his vacant eyes. The couch is empty. No card, sound punchline, logo, subscribe request, or extra sentence. End after the final word and 0.25-second tail.

## 8. ROAST CARD INVENTORY
Charcoal rounded cards, cream/white sans-serif text, one restrained gold accent matching the crown. Place them in upper empty space; never over faces or lower captions. One primary card at a time. Keep all text mobile-readable.

C01: AUTHOR EXEMPTION: NOT FILED. Generic form status. Reveal after N003 exceptions, hold 1.8 seconds into S03, then clear.
C02: APPEAL ATTACHMENT: HIS OWN SIGNATURE. Generic document attachment. Reveal after N006 rejected them himself, hold 2.5 seconds, then clear.
C03: JURISDICTION: ALSO YOUR LAWN. Tiny official-looking but visibly fictional status card. Reveal after N007 throne, hold 1.8 seconds into S05, then clear.
C04: FICTIONAL FINE / 2 items × $25.00 × 4 days = $200.00. A larger cream receipt insert with charcoal text, not a tiny footer. Reveal only after N009 dollars, hold 3.5 seconds across S06–S07, then clear. It supplies arithmetic beyond the spoken total. No other card is visible with it.

If phone-size inspection shows a card is unreadable, simplify its layout or extend into neutral narration without covering the next joke. Never compress it into a 0.30-second gap.

## 9. ACTING AND CAMERA
Greg's thought progression is self-appointed authority → procedural dismissal → insulted surprise → pride in a childish workaround → depleted dignity. Express it with eye direction, brow angle, a small chin lift, hands, and posture. The clerk stays restrained. Reuse supported Toon moods such as smug, shock, worried, and tired with look/arm changes; do not assume a nonexistent named preset.

Use stable camera paths and time-driven poses. Store a project seed for procedural variation so preview and final agree. Headwear follows the head, the clerk's clipboard follows the hand, and the chair is carried rather than teleported within a shot. Avoid noisy mouth movement: one offscreen narrator tells all dialogue. Do not turn the eight scenes into eight static posters with zooms.

## 10. SOUND AND MUSIC
Use a quiet built-in bounce bed if available, mixed below speech; otherwise choose a restrained supported bed and report the substitution. Duck it beneath N002's comparison and N004's final clause. Stop it before N009's spoken total; leave it off through the ending so the bag-color request and final callback land dry.

Use only a soft stamp after the N006 revelation, light paper handling during S02, and optional quiet chair creak after N004. Reuse supported procedural sounds; create a small original substitute or omit a nonessential unavailable cue. Do not invent a licensed recording or add constant error buzzes. No cue covers a punchline, and the double-tap silence is truly quiet. Listen for clipping, abrupt joins, and inconsistent narration loudness.

## 11. CAPTIONS AND AUDIO-FIRST TIMELINE
Use Tall Tale's white outlined one-word or short-phrase captions, no yellow speech highlights, at most two lines. Reserve gold for roast cards. Keep them below the main action with enough margin for the platform controls; inspect the actual phone-size framing rather than relying only on coordinates.

Use the final measured WAV as the timing authority. Produce data/narration.wav, data/lines.json with duration and indexed text/start/end lines, and data/words.json with w/line/s/e entries. Explicitly map N001–N012 to renderer cut-line indices when a paragraph spans multiple shots. Export narration_timeline.json and subtitles.srt too; the new timeline alone does not drive the existing renderer.

Check transcript coverage, ordered positive durations, bounds, repeated words, and sync at the opening, midpoint, and ending. Do not clamp accurate words into guessed cut windows. If word alignment is unreliable, use measured phrase captions and state the limitation. For repeated trigger words, select the exact occurrence rather than accepting the first prefix match returned by Wd. The root narration.wav deliverable must match data/narration.wav.

## 12. THUMBNAIL AND COVER
Render the existing characters and props into a cover. Greg fills the right foreground, crown gleaming, staring in disbelief at his own fictional notice. The clerk's calm hand and clipboard enter from the left; the absurd patio throne is visible but small in the background. Sunny miniature neighborhood, clean separation, navy/orange character colors retained.

Exact cover text: HE FINED HIS OWN CROWN
Optional alternative: NO EXCEPTIONS, YOUR MAJESTY
Use large white and gold type with a dark edge, one focal point, and minimal clutter. Do not show the bag-color request or final indoor couch. No image-generation service is needed. Export thumbnail.png at 1080×1920 and, if supported, a separately composed thumbnail_landscape.png at 1280×720; do not simply stretch the portrait.

## 13. PUBLISHING METADATA
Title: His Crown Violated His Own HOA Rules
Alternatives:
- He Fined Himself for Being King
- The Neighborhood King Needed Written Approval
- His Throne Came With a Daily Fine
Opening text: None; open on the action.
Description: Original fictional animated comedy about an HOA president trapped by his own decoration rules. All characters, notices, policies, and fine amounts are invented.
Hashtags: #Shorts #DarkComedy #FunnyAnimation #HOASatire #OriginalComedy #AnimatedStories
Prepare metadata only. Do not upload the video or cover to any service.

## 14. PRODUCTION AND EXPORT
Inspect the installed capability, create the project, synthesize/listen to the narration, finalize pauses, measure it, and generate compatible timing. Build the reusable yard/interior and custom props. Render a representative short sample covering a crown gesture, a card, and the bag/clipboard reveal with narration. Inspect its animation, phone readability, and sound. Measure throughput before estimating full-render time.

Correct demonstrated issues, then render the complete film. Default export: vertical 1080×1920 MP4, H.264 video, AAC audio, 30 fps. Allowed fallbacks are 720×1280 and/or 24 fps while preserving 3D sets and cutout characters; report any fallback accurately. Keep draft and final filenames separate.

Treat CHECK FAILED as failure even if a tool exits zero. Check the FFmpeg exit status, nonempty output, successful decoding, intended video/audio streams, actual resolution/fps, and duration below 75 seconds. Inspect a contact sheet and transition frames, then watch/listen to the whole final output. If the environment cannot play it, explicitly state that QA limitation instead of claiming full audiovisual verification. Bound repair attempts and report a concrete unresolved blocker rather than looping indefinitely.

## 15. ACCEPTANCE AND DELIVERABLES
Confirm the canonical narration appears once with no missing/repeated words. The crown must be introduced within the first 10 seconds; N012 must occupy the final 10. The fine cannot appear before the spoken amount. N009's 0.50-second gap is not duplicated by a scene hold. The bag covers only the crown. The clerk's sample request does not create another fine. Greg and the same throne move indoors for the closing callback. Keep C04 readable and clear it before the swatch reveal if needed by adjusting its start/hold within the measured timeline.

| Figure | Basis/formula | Result |
| --- | --- | --- |
| Fictional daily fine | Stated invented rule; no tax or appeal fees | $25.00 per item per day |
| Counted items | One crown plus one throne | 2 items |
| Counted display period | Four full fictional display days while appeal is pending | 4 days |
| Fine total | 2 × $25.00 × 4 | $200.00 |
| Extra charge for bag | No such charge in the story | $0.00 |

Deliver final_video.mp4, narration.wav, narration_timeline.json, subtitles.srt, thumbnail.png, optional thumbnail_landscape.png, script.md with the canonical narration, youtube_metadata.txt, and the editable project including data/lines.json, data/words.json, data/cues.json, and data/mix.wav. Report actual duration, format, alignment quality, checks completed, and any fallback. Preparing this prompt has not performed those future render checks.

Complete and verify the animated film and cover; do not stop after producing a storyboard. Do not publish or publicly host anything.
```

Writer-side audit: 148 spoken words; 12 paragraphs; 3.05 seconds of boundary silence plus 0.50 seconds of lead/tail; estimated 51.11–64.23 seconds at 185–145 baseline WPM with the listed speeds. No speech or video has been generated. Final callback: “And his crown retained full authority over the couch.” This is an adaptation of Example 02, so it is not claimed as a new-premise freshness pass. The format is the reusable lesson, not the crown, fine, or clerk.
