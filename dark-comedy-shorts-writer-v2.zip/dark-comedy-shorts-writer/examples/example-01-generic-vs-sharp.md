# Example 01 — Paying to Ignore a Bill

Craft calibration only: this older compact script format is not the current complete deliverable. Follow [the production prompt contract](../references/production-prompt.md) for full output and timing; the example timings below are illustrative, not measured audio.

## Generic version — rejected

Priya hated dealing with medical bills. She downloaded an app that promised to make life easier. At first, everything seemed fine. Then she discovered she still owed the money and had also paid for the app. Customer support was no help. Priya got upset and deleted it. The lesson was that ignoring your problems only makes them worse.

Why it fails: the ending lectures; no planted object returns; support has no distinct motive; there is no petty second hit; the language could describe any app.

## Sharper version

**Title:** She Subscribed to Ignoring Her Medical Bill

**Hook:** A digital concierge achieves exactly the wrong kind of peace.

**Blueprint:** Literal Genie / Malicious Compliance — faithfully hiding payment requests creates the cost.

**Intensity:** 2, using adult financial dread without violence.

**Vocabulary world:** Customer support.

**Assumptions:** US adults; 60 seconds; fictional concierge and medical account; Priya Patel; prior-story rotation baseline unknown. The existing medical balance is context. Her choice to pay for concealment is the flaw.

**Logline:** She paid a concierge to hide every payment request, so paying extra to remain uninformed was the only possible result.

**Plant/payoff:** DO NOT DISTURB sign is spoken and shown at 0–10s; it returns at 55–60s as a description of who was actually free to leave. Final spoken callback: "And DO NOT DISTURB worked. Only the money left."

### MATH CHECK

These are fictional ledger inputs, not a prediction about actual medical collection practices. The provider-held balance has no payments, added interest, or fees during this story's one-year window. Concierge charges include any applicable tax; tip is requested but not paid.

| figure | formula | result |
| --- | --- | --- |
| Existing medical balance | Given fictional patient responsibility | $600.00 |
| Concierge monthly charge | Given all-in fictional subscription price | $15.00/month |
| Elapsed year | 1 year × 12 months/year | 12 months |
| Concierge paid | $15.00 × 12 | $180.00 |
| Medical balance remaining | $600.00 + $0.00 added charges − $0.00 payments | $600.00 |
| Total paid plus still owed | $180.00 paid + $600.00 owed; not a single new bill | $780.00 |
| Additional tip paid | Request declined; no transaction | $0.00 |
| Runtime | 10 + 15 + 15 + 15 + 5 seconds | 60 seconds |

### Script

| TIME | NARRATION | CARD TEXT | FACE / ANIMATION | SFX |
| --- | --- | --- | --- | --- |
| 0–10s — Lazy Goal | Priya subscribed to ignoring her medical bill. She hung a DO NOT DISTURB sign over her laptop. | FICTIONAL CONCIERGE; SERVICE TYPE: AVOIDANCE | Reveal the sign after the opening sentence; ordinary adult at kitchen table. | Soft startup chime after "laptop." |
| 10–25s — Smug Phase | For fifteen dollars a month, a digital concierge archived anything requesting payment. She called it financial wellness. Her anxiety now had a dedicated customer success manager. | RESOLUTION METRIC: MESSAGES HIDDEN | Smug squint; 0.3s freeze after "wellness." | Gentle confirmation click during the freeze. |
| 25–40s — Cold Escalation | The service also archived its own renewal notices. She had specifically requested that. Receipts were ruining the vibe. After a year, she asked whether her balance was smaller. Support said, "Your inbox is. Different department." | TICKET CATEGORY: EXPECTATIONS | Blank stare at the reply; sign stays in frame. | None; let the support line land cleanly. |
| 40–55s — Panic + Double-Tap | Her six-hundred-dollar bill remained. Silence had cost another hundred eighty. She canceled. The concierge requested a tip for bringing all her reminders back. | After the cost lands: $600.00 owed + $180.00 paid = $780.00; FICTIONAL LEDGER | Bug-eyed panic; 0.5s silence after "She canceled," before the tip request. Hold ledger for 4s. | Small cash-register click after "hundred eighty"; silence through the gap and tip line. |
| 55–60s — Sarcastic Moral | And DO NOT DISTURB worked. Only the money left. | SATISFACTION SURVEY: REMINDER ENABLED | Hollow stare under the unchanged sign; slight zoom. | None; final line gets the whole frame. |

**Final spoken moral:** And DO NOT DISTURB worked. Only the money left.

**Alternative titles:** "Her Inbox Got Better Before Her Finances"; "She Outsourced Opening Her Medical Bill"; "The Concierge Managed Her Awareness."

**Opening text:** FINANCIAL WELLNESS, SORT OF

**Description:** Original fictional comedy about a concierge that hides bills. All characters, account figures, fees, and screens are invented.

**Tags:** dark comedy, fictional story, subscription satire, faceless shorts.

### Checklist notes

PASS: premise in the opening seven words; audible sign plant and callback; the concierge follows the exact requested service; friendly competence is its cold motive. Fresh metaphor: anxiety has a customer success manager. The $180.00 avoidable expense is the main consequence; asking for a tip to undo concealment is the smaller hit. Cards add a classification, wrong metric, ledger total, and survey behavior. The original medical bill is not treated as deserved punishment.

Math: $15.00 × 12 = $180.00; $600.00 + $180.00 = $780.00 in paid-plus-outstanding exposure. No interest claim or legal collection claim. US names/formatting, safety, clean opening, original treatment, title lengths, and audio-only comprehension pass. Narration and delivery are checked in the production note below; timing remains an estimate until recorded.

**Editorial score:** 9/10 — causality 2, freshness 2, callback 2, double-tap 2, production clarity 1. Publisher must keep the mixed paid/owed ledger label visible.

**Production note:** 112 spoken words, expanding hyphenated number phrases; estimated 60s at approximately 150 words/minute plus holds. Allow 0.3s for the face freeze and 0.5s for the double-tap. No recorded read has been measured. Do not read metadata or the repeated moral twice. Verify current prices, rules, and YouTube policies before publishing.
