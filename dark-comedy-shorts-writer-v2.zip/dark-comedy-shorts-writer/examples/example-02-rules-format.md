# Example 02 — The HOA Crown

Craft calibration only: this older compact script format is not the current complete deliverable. Follow [the production prompt contract](../references/production-prompt.md) for full output and timing; the example timings below are illustrative, not measured audio.

## Generic version — rejected

Greg became HOA president and made a lot of annoying rules. Everyone disliked him. Then he broke his own rules and got fined. He complained, but the neighbors said rules were rules. Greg had to pay and learned that being too controlling can backfire.

Why it fails: no actual rules, no checkable fine, no distinctive prop, no escalation beyond the obvious reversal, and a moral that explains the premise.

## Sharper version

**Title:** The HOA President Fined His Own Crown

**Hook:** Greg's no-exceptions policy finally recognizes his leadership.

**Blueprint:** Rules / Terms of Service — three public rules supply the entire trap.

**Intensity:** 2; petty social ruin, no violence required.

**Vocabulary world:** HOA bylaws and property compliance.

**Assumptions:** US adults; 60 seconds; Greg Miller; entirely fictional HOA rules and enforcement. Prior example: Priya, cheerfully helpful support. Current cold motive: pedantic compliance.

**Logline:** He banned every unapproved outdoor decoration without exceptions, so fining his own ceremonial crown and throne was the only possible result.

**Plant/payoff:** Gold plastic crown at 0–10s; reduced to authority over indoor furniture at 55–60s. Final spoken callback: "And his crown retained full authority over the couch."

### MATH CHECK

The fictional rule permits one daily charge per unapproved item. Both items remain displayed outdoors for all four counted days; appeals do not pause this invented rule. This is satire, not a statement of real HOA enforcement law. No appeal fees, interest, tax, or additional penalties.

| figure | formula | result |
| --- | --- | --- |
| Stated rules | Approval + daily fine + no exceptions | 3 rules |
| Daily item fine | Given fictional rule | $25.00/item/day |
| Unapproved items | 1 crown + 1 throne | 2 items |
| Counted days | Given fictional display period | 4 days |
| Crown fine | 1 × $25.00 × 4 | $100.00 |
| Throne fine | 1 × $25.00 × 4 | $100.00 |
| Total fine | 2 × $25.00 × 4 | $200.00 |
| Runtime | 10 + 15 + 15 + 15 + 5 seconds | 60 seconds |

### Script

| TIME | NARRATION | CARD TEXT | FACE / ANIMATION | SFX |
| --- | --- | --- | --- | --- |
| 0–10s — Lazy Goal | Greg banned his neighbors' ugly yard decorations. He wore a gold plastic crown to announce his HOA rules. | FICTIONAL HOA; SELF-APPOINTED BEAUTIFICATION CHAIR | Low-angle crown reveal; ordinary suburban lawn, clearly illustrated. | Dry stamp after "rules." |
| 10–25s — Smug Phase | Rule one: outdoor decorations need approval. Rule two: unapproved items cost twenty-five dollars each, daily. Rule three: no exceptions. His ego had applied for a zoning variance. | AUTHOR EXEMPTION: NOT FILED | Smug squint; 0.3s freeze after "no exceptions." | Soft click during the freeze. |
| 25–40s — Cold Escalation | The compliance clerk inspected Greg's own lawn. Crown: unapproved. Throne: also unapproved. He had denied his own application unread. Greg appealed for four days without removing either. He called them symbols of authority. | APPEAL ATTACHMENT: SELFIE | Slow zoom on Greg proudly presenting his own evidence. | None. |
| 40–55s — Panic + Double-Tap | The clerk agreed. Decorative symbols. That cost him two hundred dollars. He covered the crown with a trash bag. The clerk requested a bag-color sample. | After cost lands: 2 items × $25.00 × 4 days = $200.00; FICTIONAL FINE | Bug-eyed panic, then 0.5s silence after "trash bag" before the sample request. Hold math for 4s. | Error buzz after "two hundred dollars"; no sound over the second hit. |
| 55–60s — Sarcastic Moral | And his crown retained full authority over the couch. | None | Crown and throne now indoors; hollow stare at an empty couch. | None. |

**Final spoken moral:** And his crown retained full authority over the couch.

**Alternative titles:** "His Crown Violated His Own HOA Rules"; "The Neighborhood King Needed Written Approval"; "He Made No Exceptions for Himself."

**Opening text:** CURB APPEAL HAS A NEW MANAGER

**Description:** Original fictional HOA satire. The characters, rules, fine schedule, and notices are invented.

**Tags:** dark comedy, HOA satire, original comedy, faceless shorts.

### Checklist notes

PASS: opening premise takes seven words; crown planted audibly in the first 10s and reclaimed in the last five. Every consequence applies a published rule. The $200.00 fine is the main hit; demanding a color sample for the attempted cover is pettier. The final line gives the crown a humiliatingly small jurisdiction. Fresh metaphor: ego seeking a zoning variance. Cards reveal his missing exemption, his self-incriminating attachment, and the arithmetic.

Math: 2 × $25.00 × 4 = $200.00. All money is fictional and correctly formatted. Greg follows Priya; the pedantic clerk differs from the helpful concierge. No identity targeting, violence, real-brand allegations, or restricted opening words. The ending works without the couch card.

**Editorial score:** 9/10 — causality 2, freshness 2, callback 2, double-tap 2, production clarity 1. Keep all three rules short and audible.

**Production note:** 114 spoken words, expanding hyphenated number phrases; estimated 60s at approximately 150 words/minute plus holds. Includes a 0.3s smug freeze and 0.5s double-tap pause; no recorded read has been measured. Verify current prices, rules, and YouTube policies before publishing.
