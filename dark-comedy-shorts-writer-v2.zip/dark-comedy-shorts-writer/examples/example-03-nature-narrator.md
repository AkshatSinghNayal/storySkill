# Example 03 — The Office Gatekeeper

Craft calibration only: this older compact script format is not the current complete deliverable. Follow [the production prompt contract](../references/production-prompt.md) for full output and timing; the example timings below are illustrative, not measured audio.

## Generic version — rejected

Maya wanted to be important at work, so she refused to teach anyone how she did her job. Her boss thought she was useful. Then Maya wanted a vacation, but nobody could cover for her. She stayed at work and regretted not sharing. The moral is that teamwork matters.

Why it fails: familiar office lesson, no sustained documentary voice, no audible callback, no financial specificity, and no petty second hit.

## Sharper version

**Title:** She Made Herself Too Essential for Vacation

**Hook:** An office gatekeeper builds a habitat she cannot leave.

**Blueprint:** Fake Documentary / Nature Narrator — observe a territorial strategy becoming confinement.

**Intensity:** 1.

**Vocabulary world:** Nature documentary; office terms describe the literal setting.

**Assumptions:** US adults; 60 seconds; Maya Brooks, fictional office employee; nonrefundable hotel booking made before vacation approval. Previous protagonist: Greg. Current cold motive: a selfish boss who prefers routing questions to Maya over learning the work.

**Logline:** She made herself the only source of instructions and refused a handoff, so becoming unable to leave her own system was the only possible result.

**Plant/payoff:** ASK ME mug appears and is spoken at 0–10s. At 55–60s it becomes a tracking collar, making her territorial display into a tether. Final spoken callback: "And the ASK ME mug became a tracking collar."

### MATH CHECK

Fictional hotel rate includes taxes and fees. Both prepaid nights are forfeited under the stated nonrefundable booking; no additional cancellation charge. Available PTO is a fictional employer benefit, not a national entitlement.

| figure | formula | result |
| --- | --- | --- |
| Hotel nightly price | Given all-in fictional rate | $240.00/night |
| Prepaid nights | Given booking length | 2 nights |
| Total forfeited booking | $240.00 × 2 | $480.00 |
| Refund | Given nonrefundable terms | $0.00 |
| Net lodging loss | $480.00 prepaid − $0.00 refunded | $480.00 |
| PTO remaining | 11 available days − 0 days taken | 11 days |
| Runtime | 10 + 15 + 15 + 15 + 5 seconds | 60 seconds |

### Script

| TIME | NARRATION | CARD TEXT | FACE / ANIMATION | SFX |
| --- | --- | --- | --- | --- |
| 0–10s — Lazy Goal | Maya made herself impossible to replace. Her ASK ME mug guarded a desk where every instruction ended with "ask Maya." | HABITAT: CLIMATE-CONTROLLED DEPENDENCY | Reveal the mug; slow documentary push toward a fictional adult at her desk. | Soft office ambience under the setup, fading before the next beat. |
| 10–25s — Smug Phase | Observe the office gatekeeper. She hides the process notes, then feeds on questions. Her knowledge is nesting material available only in her territory. Management calls her essential. | LOCAL POPULATION: INCREASINGLY DEPENDENT | Smug squint; 0.3s freeze after "essential." | One soft startup chime during the freeze. |
| 25–40s — Cold Escalation | She books two hotel nights at two hundred forty dollars each. The boss offers vacation if she shares instructions. Maya refuses. Sharing would contaminate the habitat. | MIGRATION CONDITION: RELEASE THE NOTES | Slow pan from concealed notes to a suitcase. | None. |
| 40–55s — Panic + Double-Tap | She cancels the nonrefundable trip. Four hundred eighty dollars buys an empty room. The boss sends every question to her personal phone, which she listed as emergency contact. | FICTIONAL BENEFIT: 11 PTO DAYS, ALL UNUSED | Bug-eyed panic at the empty hotel-room illustration; 0.5s pause after "empty room," then phone lights up. | Notification ping only after "emergency contact." |
| 55–60s — Sarcastic Moral | And the ASK ME mug became a tracking collar. | None | Mug stays on desk beside phone; hollow stare. No literal animal or collar injury. | None. |

**Final spoken moral:** And the ASK ME mug became a tracking collar.

**Alternative titles:** "The Office Gatekeeper Cannot Leave Her Habitat"; "Her Vacation Required Sharing the Instructions"; "She Became Her Own Vacation Obstacle."

**Opening text:** THE OFFICE GATEKEEPER, OBSERVED

**Description:** Original fictional workplace comedy told as a nature documentary. The employee, employer, hotel terms, and benefit figures are invented.

**Tags:** workplace satire, nature narrator, original comedy, faceless shorts.

### Checklist notes

PASS: six-word opening premise; audible mug plant and spoken callback; a handoff is offered, and Maya actively refuses it. Her own gatekeeping creates the forfeited trip; expanding that gatekeeping to her personal phone is the smaller hit. The boss's self-interest differs from the previous pedantic clerk. Fresh metaphor: knowledge as nesting material. The ending works without any cards, and the voice remains within the documentary world.

Math: $240.00 × 2 = $480.00; no invented extra fee; 11 PTO days remain because none are taken. Maya follows Greg. Cards supply ecological classifications and unused-benefit information rather than transcribing narration. US localization, clean opening, title limits, original treatment, and Level 1 safety pass. No joke targets illness, identity, or involuntary unemployment.

**Editorial score:** 9/10 — causality 2, freshness 2, callback 2, double-tap 1, production clarity 2. The phone notification should stay small; the collar line is the strongest ending.

**Production note:** 110 spoken words; estimated 60s at approximately 140 words/minute plus holds, including 0.3s for the smug freeze and 0.5s between the empty-room consequence and personal-phone indignity. No recorded read has been measured. Verify current prices, rules, and YouTube policies before publishing.
