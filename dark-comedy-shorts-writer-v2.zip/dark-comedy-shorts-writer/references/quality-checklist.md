# Creative and Production Handoff Checklist

Use this before a complete prompt. Fix failures and their dependencies before delivering an original story. If a user locks incompatible requirements, explain the conflict rather than silently rewriting or declaring a pass. For ideas-only or narrow edits, mark unrelated production gates not applicable. Distinguish editorial judgment, calculated estimates, and checks requiring actual rendered media.

## Story and comedy

- [ ] The first sentence and frame establish a specific adult situation quickly; the spoken opening is plausibly deliverable within roughly three seconds.
- [ ] A clear desire and chosen shortcut create the trap. Every escalation has an understandable cause; no secret rule or random catastrophe invents the ending.
- [ ] The flawed actor is identified separately from the narrator. Innocent witnesses can escape, cooperate, or win without becoming the target.
- [ ] An audible concrete plant is planned within the first 10 seconds, returns in the final 10, and is reinterpreted in the final spoken line. These windows remain subject to measured-audio checks.
- [ ] The main consequence and smaller indignity come from the same mechanism; their silence appears once in the timing plan. The final line may also be the petty second hit.
- [ ] No explanatory moral, duplicate callback, or promotional coda follows the strongest ending.
- [ ] The story works with all cards removed. At least one specific observation/comparison is new to this story; jokes change the information, status, or expectation instead of merely repeating it.
- [ ] Dialogue remains understandable with one narrator. Perspective, pronouns, actors, and chronology remain consistent.
- [ ] The chosen metaphor world is coherent without forcing every sentence into jargon. Mild profanity is optional, never the joke's only force.

## Freshness

- [ ] An open-topic request received genuinely different premise options internally before selection; a supplied premise was respected.
- [ ] Available recent stories were compared by mechanism, consequence, perspective, callback prop, and setting. The new story is not an example with renamed characters or another identical fee/rejection ending.
- [ ] Repeated characters or setting are intentional when requested. Otherwise names and motives rotate naturally.
- [ ] The audit states "rotation baseline unknown" if history is unavailable; no claim of exhaustive originality or invisible memory.
- [ ] The story earns its length with causal developments, not more cards or repetitions. No promise of virality, monetization, or guaranteed engagement.

## Complete prompt and voice contract

- [ ] All 15 sections in production-prompt.md are filled with story-specific decisions in one self-contained copyable prompt. No placeholders, partial scenes, or references to this conversation.
- [ ] Exactly one BEGIN_NARRATION/END_NARRATION block contains all and only performed words. No headings, IDs, emotions, UI text, or production commands are sent to TTS.
- [ ] Every narration paragraph has one ordered manifest row N001 onward, with numeric speed, total boundary silence, and a delivery note. No missing/duplicate paragraphs.
- [ ] Spoken word count expands numbers and counts dialogue once. Every intentional pause, lead, tail, and extra hold is budgeted once. Overlapping card holds do not double-count time.
- [ ] Duration is calculated as a range under stated assumptions. A script that needs rushed speech is revised before locking; actual audio is not claimed before synthesis.
- [ ] Exact user text is preserved when locked. A runtime or content conflict is reported rather than concealed.
- [ ] The preferred voice and language match the installed backend, or the prompt directs validation. Per-segment speeds require implemented support; emotion notes are not fictitious API controls.

## Film direction and compatibility

- [ ] The selected visual type is explicit. Tall Tale is 2D cutout people in 3D sets; no accidental promise of fully modeled people or silent 2D fallback.
- [ ] Scene coverage includes every paragraph exactly once as performed narration; shared IDs across internal shots are explicitly continuous playback, not repeated speech.
- [ ] Each shot has a concrete composition, action, anchored reveal, expression progression, and transition. Character/prop IDs and carried objects remain consistent.
- [ ] A teaser states exactly what is disclosed. All other visual/card punchlines follow their spoken reveal.
- [ ] Cards are additive, one primary card at a time, with exact copy and usable reading holds. They remain clear of faces, accessibility captions, and platform controls.
- [ ] Caption styling matches the selected engine or declares an implemented extension. White Tall Tale captions are not accidentally given a generic yellow-highlight requirement.
- [ ] The prompt requires existing renderer timing files plus the exported timeline/SRT, with a mapping from narration paragraphs to cut lines. It does not assume the new JSON file alone drives the renderer.
- [ ] It requires measured segment boundaries, alignment quality checks, no negative/zero timestamps, and honest phrase fallback when words cannot be aligned reliably.
- [ ] Music and effects leave room for punchlines and silence. Missing sounds/props have realistic small-extension or substitute instructions.
- [ ] A representative sample precedes the full render; procedural randomness is reproducible; quality/frame-rate fallbacks are named accurately.
- [ ] Process status, failure messages, output existence/decoding, streams, runtime, playback, and audiovisual QA are explicitly required before success is claimed.

## Math, content, and packaging

- [ ] Story figures have an input/formula and verified arithmetic; fictional charges/rules are labeled. Legal or financial plausibility is not inferred from correct arithmetic alone.
- [ ] Locale, names, units, chronology, and institutions are consistent. An explicit user locale override is applied throughout.
- [ ] Content follows adult-content-and-violence.md; satire targets an individual's conduct, not an identity group. No banned premise is hidden behind euphemisms or an offscreen cue.
- [ ] Titles and thumbnail text follow the conservative opening rules. Every main/alternative title is at most eight words. Description clearly identifies fiction; tags are relevant.
- [ ] The cover uses consistent characters and a concrete composition, with exact readable text and no final-punchline spoiler. It can be rendered from existing assets without assuming paid image tools.
- [ ] Deliverables include the MP4, matching narration, timeline, SRT, cover, canonical script, metadata, and editable project. Metadata does not authorize upload.

## Final honest report

Give concise evidence: word count, planned silence, estimated duration assumptions, final callback, a novelty fingerprint, and any real unresolved constraint. A structural audit cannot prove that a story is funny, a voice sounds natural, or the output passed playback. If audio/video has not been produced, the receiving renderer's checks are still pending. Do not attach ceremonial scores or mark unperformed checks passed.
