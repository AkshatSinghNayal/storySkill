# Voice and Metaphors

## Core technique

Describe a specific adult choice with a calm, sharply observed comparison. Ask how an exhausted but articulate American friend would tell this story. Corporate, financial, app, legal, sporting, travel, or documentary language can supply the frame; choose the one the premise earns. Do not make every relationship or household story another staffing agency.

Choose ONE vocabulary world per story. A software story may use permissions, updates, and support tickets; it should not suddenly become a courtroom, safari, and mortgage listing. Literal references to the setting are fine. Use connected sentences with natural changes in length. Reserve short fragments for the reveal or a deliberately clipped reaction. Let specific detail carry the joke; uninterrupted jargon or a punchline after every sentence makes the voice mechanical.

## Forty metaphor seeds

These demonstrate construction, not lines to paste into scripts. Invent at least one genuinely new metaphor tied to the specific flaw and prop. If it could fit any character unchanged, sharpen it.

| # | World | Seed |
| --- | --- | --- |
| 1 | Office | His apology arrived as an agenda item nobody owned. |
| 2 | Office | She put her conscience on a recurring meeting and declined the series. |
| 3 | Office | His confidence had a company badge and no assigned desk. |
| 4 | Office | The silence had already been approved by management. |
| 5 | Office | He treated accountability like a meeting someone else would take notes for. |
| 6 | Office | Her plan was a performance review written by the snack cabinet. |
| 7 | Finance | His emergency fund was a checking account with stage fright. |
| 8 | Finance | He diversified his regrets across three monthly payments. |
| 9 | Finance | Her optimism kept making the minimum payment. |
| 10 | Finance | The budget balanced only because shame was still off the books. |
| 11 | Finance | He refinanced a small inconvenience into a recurring obligation. |
| 12 | Finance | His confidence was an introductory rate with immediate expiration. |
| 13 | Software | His personality requested administrator access to a shared lunch. |
| 14 | Software | She put common sense behind a permission she never granted. |
| 15 | Software | His excuse shipped with a known issue and no rollback. |
| 16 | Software | The marriage calendar had become a read-only incident log. |
| 17 | Software | He installed a progress bar over a completely stationary problem. |
| 18 | Software | Her patience was a free tier he kept exceeding. |
| 19 | Legal | His apology reserved the right to remain the same person. |
| 20 | Legal | She entered her feelings into evidence and objected to all of them. |
| 21 | Legal | His alibi had the structural integrity of an unsigned exhibit. |
| 22 | Legal | The group chat granted him temporary custody of the consequences. |
| 23 | Legal | He treated a favor like a precedent binding on the neighborhood. |
| 24 | Travel | His dignity was the bag they measured twice at the gate. |
| 25 | Travel | Her patience had boarded; he was still arguing about zones. |
| 26 | Travel | His apology offered standby access to actual remorse. |
| 27 | Travel | He upgraded the announcement and left the experience in basic economy. |
| 28 | Travel | His life plan had a tight connection through an airport called Probably. |
| 29 | Healthcare billing | His confidence was covered until anyone asked it to do something. |
| 30 | Healthcare billing | She requested prior authorization to feel vindicated. |
| 31 | Healthcare billing | His apology applied entirely to the deductible. |
| 32 | Healthcare billing | The reassurance came itemized, with comfort listed separately. |
| 33 | Healthcare billing | His patience required a referral he had misplaced. |
| 34 | Housing | His boundaries were an open floor plan advertised as privacy. |
| 35 | Housing | She called the grudge a long-term tenant. |
| 36 | Housing | His excuse had fresh paint over a structural problem. |
| 37 | Housing | The friendship entered its security-deposit inspection. |
| 38 | Housing | He listed his emotional availability as street parking. |
| 39 | Housing | Her optimism was a model unit nobody actually lived in. |
| 40 | Housing | His dignity became a furnished sublet with no renewal option. |

## Stale list: do not use

"two brain cells"; "404 not found"; "generational debt"; "expensive furniture"; "cancel subscription to life"; "IQ: room temperature"; "HR promoted him to customer"; "job security" as a name; "never teach a computer your job."

Avoid small paraphrases of these too. Do not replace "two brain cells" with "one brain cell on vacation" and claim freshness. Do not use the bank above as a substitute for invention.

## Sentence and timing rules

- First spoken sentence: premise, preferably five to eight words; actual delivery must fit under three seconds.
- Choose length from the story and the explicit pause budget. Use the word/speed/pause calculation in production-prompt.md; word bands are not proof of fit. A 384-word story plus 26.45 seconds of pauses takes about 154–170 seconds at 180–160 spoken words per minute before additional holds. Do not label it 100–130 seconds or accelerate it to rescue a bad estimate.
- Count spoken dialogue inside narration. Exclude headings, stage directions, cards, and the repeated production-reference moral. Expand numbers into how they will actually be spoken when estimating time.
- Keep connective tissue where it helps causality. Avoid backstory dumps, rhetorical-question barrages, "little did he know," repeated "Apparently," and a closing explanation of the joke. Choose first-person or third-person deliberately and preserve it through quoted dialogue.
- Budget 0.3 seconds for a face freeze and 0.5 seconds between consequence and petty hit. Pauses are part of the runtime.
- Use dry US office and money idiom when it fits the world: "per my last email," "circle back," "PTO," "at-will," "side hustle," "doom-scrolling." Use "send me your share" for a payment request; "Venmo me" is an idiom, not permission to build a real-brand allegation.

## Adult language and opening wording

Adult means cynical treatment of adult responsibilities. No slurs, hate, heavy profanity, or sexual content. Mild "damn" or "hell" may appear sparingly; a clean version should retain the joke.

As this skill's conservative editorial rule, never put "kill," "die," "suicide," "murder," "blood," or "gore," or their direct inflections, in the title, thumbnail text, first spoken sentence, or first five seconds of any track. This is not an official YouTube keyword blacklist or a loophole.

For an allowed later afterlife reference, prefer bureaucratic understatement such as "permanently offboarded" or "deceased, pending paperwork." Do not use euphemisms to sneak banned content past the safety gates. "Deceased, pending paperwork" belongs after the opening, not in thumbnail copy. Context and depiction matter throughout the video.
