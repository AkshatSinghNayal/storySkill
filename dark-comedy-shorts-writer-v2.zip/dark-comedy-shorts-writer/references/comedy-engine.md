# Comedy Engine

## Deserved misfortune

The flawed adult volunteers for the trap by being lazy, greedy, controlling, or overconfident. The narrator can be that adult, a witness, or the person who stops accommodating them; an innocent narrator does not need to be punished. Debt, disability, unemployment, illness, and poverty are not character flaws. Start with a relatable pressure; punish the chosen shortcut. Innocent bystanders do not absorb the consequence.

Build this chain: adult problem → selfish shortcut → temporary success → a consequence created by that shortcut → a specific petty remainder. Literal compliance is one possible mechanism, not a requirement for every story. Each arrow must mean "because," never "and then something unrelated happened."

Write a causal logline naming the choice, consequence, and connecting mechanism. If another random person could receive the same ending without making that choice, the causal design is weak. Change the ending or the plan. An accident caused by the scheme may expose it, but a random outsider or new rule must not manufacture the ending.

## Internal logic and delivery

- Give the fool total discipline. A man who calls every purchase an investment must demand a quarterly report from his air fryer.
- Introduce the rule before enforcing it. A secret fee can surprise the character, but establish the fee category or agreement early enough that the audience can reconstruct the trap.
- Keep the narrator calm. Report humiliation like a revised delivery estimate. No "You won't BELIEVE," shouting, winking, or explaining why the moment is funny.
- Use precise, credible details: $47.18 composed of disclosed charges; 11 PTO days; a shared password across six departments. Precision must have a source or fictional input, not merely sound official.
- The stakes can be ordinary. Losing a Saturday to your own cancellation system can be darker and funnier than a gratuitous catastrophe.

## Plant and payoff

Plant a small, boring object or rule in the first 10 seconds: a mug, sunglasses, membership card, warranty, fictional app label, or handwritten sign. It must be audible if needed to understand the final joke. Keep it visible without announcing "remember this."

Return it in the final 10 seconds with changed status, ownership, cost, or meaning. The last spoken line delivers the reinterpretation. "And his VIP lanyard became the only thing allowed a break" works only if the lanyard and his self-imposed access rules were established. "Don't be greedy" never qualifies.

## The rule of two: double-tap

1. Deliver the main consequence in narration.
2. Leave 0.5 seconds of silence; hold the face.
3. Deliver a smaller indignity caused by the same rule.
4. End on the spoken callback, which may sharpen that smaller indignity.

Example: he becomes the sole contact for all customer complaints. Pause. His own support system charges him to ask for a chair. Do not follow an eviction with an unrelated meteor. Petty means less severe, more specific.

## Cold-character motive menu

| Motive | US-flavored response |
| --- | --- |
| Selfish landlord | Accepts the tenant's offer to perform every repair; forwards the tenant's own repair request back to him. |
| Bureaucratic HR | Uses the employee's self-written "owner must approve" rule to route his PTO request to his unavailable self. |
| Pedantic insurer | Explains that the character's fictional "emotional support fax" is office equipment under the plan he selected. |
| Cheerfully helpful chatbot | Successfully removes all bill notifications while leaving the bills exactly where they were. |
| Uselessly literal contract | Grants "unlimited guest access" to the gym's guest Wi-Fi, because that is the service the character actually purchased. |

Vary the motive across adjacent stories. Coldness is not always greed; competence faithfully serving the wrong request is often better. Never default to a greedy parent.

## Ten joke engines

| Engine | One-line US example |
| --- | --- |
| Literal interpretation | A manager asks for fewer complaints; the bot closes the complaint form. |
| Policy absurdity | A worker writes a policy requiring advance notice for spontaneous brainstorming. |
| Escalating commitment | A renter buys more storage bins to avoid admitting the first bin contains only other bins. |
| Status inversion | The employee who reserves every conference room must now ask the office plant for a quiet space. |
| Wrong-metric success | A delivery-app obsessive reduces delivery fees by spending more on food he cannot finish. |
| Fine-print reversal | A gym member buys "flexible access" and discovers he selected the stretching room. |
| Subscription trap | A man pays monthly for a service that hides every renewal notice, including its own. |
| Hidden fee | A self-appointed HOA treasurer gives himself the processing fee he voted to charge everyone. |
| Cheerful denial | A fictional benefits bot congratulates an employee on successfully withdrawing his own appeal. |
| Bureaucratic loop | The creator of an approval form cannot retire it without using the approval form. |

## Freshness and surprise pass

Before selecting an open-topic story, compare three premises with different causal mechanisms, not three versions of a bill. Judge the adult desire, the precise bad shortcut, a visual gag, and an ending that is both surprising and reconstructable. If the user supplies a premise, test different consequences within it instead.

Record a compact fingerprint: setting / flawed desire / mechanism / narrator perspective / opposition motive / figurative world / callback prop / ending mechanism. Compare the last few available stories. Unless the user requests a sequel, change the mechanism and ending plus at least one other meaningful dimension. Names, occupations, and amounts alone are cosmetic. Do not claim comparison with unavailable history.

Vary what goes wrong: loss of status, unwanted responsibility, private embarrassment, a revealed dependency, a relationship boundary, a useless victory, or a modest earned win. Fees and HR forms are options, not mandatory endings. The cast can cooperate against the selfish actor; every story need not end with a boss, bot, landlord, or cruel partner defeating the narrator.

For the chosen story:

- Write the cause-and-effect spine without jokes. It should already be understandable and interesting.
- Invent several candidate last lines and choose the strongest one supported by the planted detail. Do not add a generic lesson after it.
- Find different joke functions: a recognizable observation, a reversal, a character's sincere but defective logic, and a specific petty consequence. A string of metaphors with no changing situation is not escalation.
- Remove each joke mentally. If removing it changes nothing and it repeats the previous observation, cut or replace it. Let neutral connective sentences carry the plot.
- Test the final surprise against earlier evidence. It should reframe something we saw, not introduce a secret fourth rule or arbitrary invoice.
- Change tone through acting and information, not increasingly loud narration. A clean, unhurried line can be the biggest laugh.

## Structural variation

A twist-first opening, documentary perspective, observer narrator, or earned win can be selected without asking the user to choose from a ritual menu. Keep one coherent causal chain and the spoken callback. Clearly mark a teaser's authorized reveal in the production prompt so later no-spoiler instructions do not contradict it.

The ending can be an action line, a deadpan observation, or a short quoted response; it does not need the phrase "Moral of the story." Let the final callback also supply the petty second hit when stronger. Default to approximately 0.5 seconds between the two hits, then tune against real audio. Do not schedule the same silence twice.

## Reject these patterns

Random bad luck; innocent victims; emotional narrator reactions; explaining the joke; twists unrelated to the flaw; morals without callbacks; card-only endings; recurring cold-parent plots; consecutive first-name reuse; contradictory policies; impossible prices disguised as realistic bills; wrong math; cosmetic rewrites of the same story. Invent a new mechanism, not just a new name.
