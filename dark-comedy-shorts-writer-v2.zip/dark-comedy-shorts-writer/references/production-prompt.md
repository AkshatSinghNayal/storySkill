# Complete Production Prompt Contract

The output is a production brief for a receiving video agent, usually Antigravity using an installed `faceless-shorts` skill. Write the actual brief, not instructions telling the user how to write one. Populate every section below for this story. Its narration, direction, and metadata must make sense with no access to this skill or chat.

Keep the prompt detailed where decisions matter: exact words, character identity, physical action, comic timing, screen text, and delivery. Repeated adjectives such as "premium," "viral," or "extremely funny" do not replace direction. Do not pad every scene with a camera move, card, sound, and reaction when one clean gag works better.

## 1. Project objective and creative decisions

Give the project title, original fictional premise, audience, intensity, narrative perspective, and flawed actor. Identify the comic mechanism, vocabulary world, early plant, and ending function. State the estimated duration range and hard ceiling under 180 seconds; it is a planning estimate until speech is measured.

Name the selected visual style accurately: Tall Tale means 2D cartoon cutouts in a 3D environment. State permitted technical fallbacks. Default to preserving that visual type while reducing render resolution/quality if needed; do not authorize a switch to flat 2D or fully modeled characters by accident. Honor an explicitly requested alternative. No claim that this fictional story is true or adapted from real events.

## 2. Exact narration — the only TTS input

Place the complete final spoken text between these literal markers, on their own lines:

BEGIN_NARRATION

Then the actual narration, in plain paragraphs.

END_NARRATION

The explanatory sentence above is not template text to output. Replace it with the entire finished script. Never put IDs, headings, timestamps, performance notes, brackets, scene directions, or card text inside this block. Quotes that are actually spoken belong here. Spell out numbers for TTS. Keep each paragraph a natural sentence or a few connected sentences, rather than one arbitrary subtitle chunk.

Paragraphs receive IDs N001, N002, and so on by order; those IDs appear only in the delivery manifest and scene directions. One narrator performs all dialogue in the same vocal identity, unless the user requests otherwise. Dialogue attribution must be understandable without separate voices. Lock these words after creative QA; the receiving agent may tune delivery, not casually rewrite jokes or omit lines. Reference the final callback elsewhere by ID and a short anchor rather than repeating the whole narration.

## 3. Skill compatibility and execution scope

Include concrete compatibility instructions from [faceless-compatibility.md](faceless-compatibility.md), adapted to this project:

- Read the installed skill and selected style; reuse their project layout, characters, renderer, and audio utilities. Inspect what actually exists instead of assuming a particular version.
- This brief explicitly selects fiction, length, and any deliberate visual overrides. A historical example's story shape or "true stories only" instruction must not replace the approved fictional story.
- Extend missing project features narrowly; do not rebuild the engine. Identify genuinely new props, set dressing, overlay types, or SFX for this story. No paid APIs or external uploads are needed for local production.
- The writing and planning phase is already complete. Continue through measured narration, a representative render test, full animation, export, and QA. A genuine missing dependency or hard constraint can be reported; never fabricate a finished render.
- Local production is authorized by the pasted production request. Do not infer permission to publish or stage the video on a public host from a request for metadata or thumbnails.

## 4. Cast, sets, and continuity

For every visible recurring adult, define an immutable ID, name/role, adult age, outfit palette, silhouette, hair/accessory identifiers, default posture, motivation, relationship to the narrator, and expression progression. Choose details supported by the style or label the small required extension. Do not describe unseen complexity that does not affect a shot.

Define the main sets and their screen geography: entrances, seating, counter/table, recurring prop positions, lighting, and reusable framing. Give the callback prop an ID, exact printed text if any, and its beginning/end states. Track what each character carries and when it is transferred. A character appearing in a thumbnail must match the film. No extra character caused by an ambiguous phrase such as "the narrator's boyfriend" when the narrator is the boyfriend.

## 5. Voice and delivery manifest

Specify one voice, general speed, US English, dry conversational delivery, and no unsupported emotion API controls. Prefer `am_michael`; only use a fallback from the installed voice inventory. Match language syntax to the actual backend, not a guessed flag.

Give one row for **every narration paragraph**, using this exact header and ID convention so the audit helper can read it:

| Segment | Speed | Pause after (s) | Delivery |
| --- | --- | --- | --- |

Use numeric speed multipliers and nonnegative pause seconds, e.g. `N001`, `1.02`, `0.25`. Populate real rows; never leave ellipses. The speed is a starting suggestion, not measured emotion. Usually stay close to the chosen global speed; do not mechanically alternate speeds or pause after every tiny phrase. Delivery notes explain one specific intention such as a delayed realization, falling emphasis, or entirely straight final word.

Pause values mean the **total intended silence at that paragraph boundary**, including a planned face hold. Trim/account for existing TTS tail silence before inserting only the missing amount. Do not add both a listed 0.5-second pause and another 0.5-second scene freeze for the same event. Prefer natural paragraph-level synthesis; if a pause inside a paragraph is essential, split it at a natural boundary so its timing is explicit. Continue music or stop it deliberately; silence for a joke may require muting music and effects as well as voice.

## 6. Honest runtime budget

Report the spoken word count, paragraph count, sum of boundary pauses, lead/tail, and any separately budgeted nonoverlapping visual hold. Use a range instead of fabricated exact audio times.

For unmeasured English speech, estimate with slow/central/fast planning baselines such as 145/165/185 spoken words per minute. These are assumptions, not Kokoro benchmarks. A multiplier is only an approximation before synthesis:

`estimated seconds = sum(segment_words × 60 / (baseline_wpm × segment_speed)) + boundary_silence + lead + tail + other_nonoverlapping_holds`

Cards that remain visible during speech do not automatically add time. Explicit reaction-only pauses do. Count quoted dialogue once; exclude cards, headings, manifest text, repeated anchor quotes, and metadata. Spell out digits and abbreviations first. Leave headroom under 180 seconds; do not target 179.9 with an unmeasured read.

If an original draft needs rushed speech or cannot fit with readable cards, tighten the story before locking it. If the user locks an overlong script, flag the conflict and offer a truthful longer format or a specific cut; never silently cut it or promise incompatible requirements. The receiver measures the combined WAV, updates all timing files, and rechecks the plant/payoff windows before rendering. Audio duration plus any true visual tail must stay below the selected cap.

When tools are available, save only a temporary draft unless the user requests a file, then run:

`python3 scripts/audit_prompt.py /path/to/draft.txt --target-seconds 90 --max-seconds 179 --lead 0.25 --tail 0.25`

Pass this project's actual lead/tail/extra holds. Inspect warnings; a valid manifest is not proof the final film fits. Without tools, count carefully and explicitly call the estimate manual. Never claim an actual read was measured.

## 7. Complete scene-by-scene direction

Provide all scenes needed to cover every narration paragraph in order, without gaps or duplicate playback. A scene is a location/dramatic unit; it may contain multiple shots. Twelve scene titles alone are not sufficient. Each scene includes:

- Scene ID, covered paragraph IDs, dramatic purpose, and any approximate time window labeled estimated.
- The opening composition, visible cast and props, framing, spatial positions, and what is hidden until its reveal.
- Ordered physical actions and shot changes tied to paragraph IDs and short exact spoken anchors. For repeated words, specify the occurrence or phrase. A movement has a starting state, action, and end state; props follow the hand holding them.
- Expressions that progress with new information: gaze target → brow/mouth change → body response → specified hold. Use supported poses or state the extension; "funny face" alone is insufficient.
- Card ID, when it appears, minimum planned reading hold, and when it clears; write `None` when the performance needs an empty frame.
- SFX/music/silence anchors and transition into the next scene. Do not add time already in the delivery table.

The first frame must communicate the situation without an explanatory title slate. A cold-open teaser is allowed only when explicitly marked: say which fact it reveals and which later discovery remains concealed. Otherwise do not show a receipt, message, expression, or card that spoils a punchline before its spoken reveal. Do not force a cut every two seconds through an awkward silence or a readable message. Every shot needs an action, discovery, or useful reaction; zooming a static card is not full character animation.

## 8. Independent UI roast cards

List every card's ID, exact copy, visual form, reveal anchor, planned hold, and placement relative to faces and captions. Choose a coherent type system and palette. Default charcoal/cream, white type, selective yellow, and purposeful status colors; do not copy Tall Tale's caption rules onto the card system or vice versa.

Cards add a classification, contradiction, or petty detail, not a transcript of the spoken joke. Usually use 3–9 words and one card at a time. As an initial reading budget, allow roughly 1.5–2.5 seconds for a short card and 3–5 seconds for multi-line arithmetic; inspect at phone size and extend if needed. A 250-ms narration gap is not a reading window. Keep a card up through a quieter following phrase when appropriate. A scene need not contain a card. Keep fictional financial/legal props visibly fictional; no real account details or company logos.

## 9. Animation, acting, and camera

Give this story's recurring gestures, expression vocabulary, character entrances/exits, prop continuity, and camera behavior. Establish one readable visual priority at a time. Facial exaggeration should express a recognizable thought, not a random distorted face. Blink and breathing can continue during a quiet hold; avoid distracting lip movement that suggests a second voice. State the stable seed/reproducibility requirement for procedural elements.

Reuse sets, camera setups, and props without replaying identical gags. Prefer controlled pushes, pans, and composition changes; avoid continuous zooming, shake, flicker, clipping, and people intersecting furniture. Distinguish the 3D environment from the 2D character system. A fallback must preserve the agreed visual type unless the user has allowed changing it.

## 10. Sound and music

Choose a restrained built-in bed or no music and list the actual story-specific cue events. Specify where music ducks, stops, and resumes; protect the exact joke words and double-tap gap. Reuse supported procedural sounds or create small original substitutes. Do not assume a vacuum, record scratch, or orchestral cue exists in the mixer. If an effect needs a new implementation, name it and allow a simpler suitable substitute without losing story meaning. No constant notification barrage or unlicensed samples. Voice stays intelligible; listen for joins, clipping, and harsh effects.

## 11. Captions and audio-first timeline

Keep accessibility captions separate from roast cards. Default Tall Tale captions are white outlined one-word/short-phrase captions, without yellow highlights. A requested highlight change must be declared as an intentional caption-renderer extension. State the maximum lines, phone-safe placement, contrast, and minimum readable size; adapt the actual layout to the selected style and check collisions in motion.

The final audio is the clock. Preserve one exact narration source, measured segment boundaries, aligned words where reliable, and the scene-to-segment map. Export `data/narration.wav`, `data/lines.json`, and `data/words.json` for the existing renderer, plus `narration_timeline.json` and `subtitles.srt`. The root-level WAV deliverable may be an identical copy of `data/narration.wav`. Map paragraph IDs to renderer cut-line indices explicitly; a paragraph need not equal a visual cut.

If word alignment is unreliable, report that limitation and use measured phrase/segment captions without pretending interpolated words are exact. Check missing/repeated words, timestamp ordering, zero/negative spans, bounds, and cumulative drift. Derive boundaries from real audio/alignment instead of clamping accurate words into guessed windows. Inserted silence must appear consistently in every exported timing representation.

## 12. Thumbnail and cover direction

Specify one concrete composition using this film's cast/props, readable emotion, foreground/background hierarchy, and exact short text. Give one optional text alternative, not a menu of unfinished designs. Sell the premise without revealing the final petty hit. Match the character palette and outfits; no watermarks or decorative clutter.

Default to rendering the existing character assets into a composed cover. Do not silently introduce image-generation services or paid tools; use them only when the user requests/allows them and the production environment supports them. Export `thumbnail.png` at 1080×1920; also `thumbnail_landscape.png` at 1280×720 if supported. A cover file does not imply it has been uploaded or accepted as a platform thumbnail.

## 13. Publishing metadata

Supply one final title, three genuinely different title alternatives (each at most eight words), exact opening text if used, a concise fictional-comedy description, and 5–8 relevant hashtags. Avoid generic bait, invented real-world allegations, and unrelated trend tags. No obligatory call to action after the closing joke. Metadata preparation is separate from publishing authorization.

## 14. Production sequence and export

Give a practical ordered workflow: inspect installed capability → create isolated project → generate/listen to narration → finalize silence and measure → produce renderer-compatible timing → build reused sets and custom shots → render a short representative sample with captions/cards/audio → inspect and fix → full render → verify playback and outputs. The sample should exercise the hardest expression, a prop action, and a card transition. Measure render throughput there before promising a full-run completion time.

Export MP4, H.264/AAC, 9:16, preferably 1080×1920 at 30 fps; list any allowed lower-resolution or frame-rate fallback explicitly. Do not label 24 fps as 30 fps. Keep previews separate from final artifacts. Require a successful render process, a nonempty decodable file, correct video/audio streams, matching runtime, and actual inspection. Do not treat the printed filename as proof. Avoid unlimited setup/render retries; report concrete blockers after bounded diagnosis.

## 15. Acceptance checks and deliverables

Give story-specific acceptance checks: canonical narration once, callback prop and final line, reveal ordering, main/petty hit with correct silence, actor identity, card reading time, captions, sound, and motion. Include a small `figure | basis/formula | result` table for spoken/displayed story numbers. Labels like scene IDs and technical resolution need not be presented as fictional money math. Distinguish the writer's preflight from checks the renderer must still perform; do not claim the future video has passed QA.

Deliver `final_video.mp4`, `narration.wav`, `narration_timeline.json`, `subtitles.srt`, `thumbnail.png`, optional `thumbnail_landscape.png`, `script.md` containing the canonical text, `youtube_metadata.txt`, and the editable project with its renderer timing files. The root WAV and renderer WAV must match. Include a brief report of actual duration, format, alignment quality, checks performed, fallbacks, and unresolved limitations. Preserve the prompt separately if useful. End the directive with completing and verifying the video, not merely the storyboard. No uploading unless separately requested.
