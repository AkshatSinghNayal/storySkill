# Visual Cards and Faces

## The second, meaner narrator

Voiceover supplies the complete story. Cards reveal a withheld cost, contradiction, status, or administrative insult. Never duplicate a spoken sentence or display its punchline before it is heard, except for a precisely identified cold-open teaser whose disclosure is intentional. Ordinary accessibility captions may transcribe narration; those are separate from joke cards.

Use one primary card at a time, usually two short lines, about three to nine words. Budget roughly 1.5–2.5 seconds for a short card as a starting point, and inspect it at phone size. It may remain through a quieter following sentence; a 0.3-second reaction pause alone is not enough to read it. Some scenes should have no card. A math card may take longer: hold it for three to five seconds and simplify surrounding narration. Keep text readable on a phone and clear of platform controls. Do not put essential jokes in tiny footers.

Realistic bills, bank alerts, legal forms, and insurance screens need a readable "FICTIONAL PROP" or "FICTIONAL BILL" label. An explanation of benefits is labeled "NOT A BILL." Avoid real logos, addresses, account numbers, seals, or executable QR codes.

## Thirty additive card examples

The setup column describes what narration has established, not words to repeat. All prices and policies below are fictional inputs; specified totals use only the listed inputs. Whole-dollar amounts still use two decimal places. These are patterns to reinvent, not a stock rotation.

| # | Format | Narration establishes | Additive card text |
| --- | --- | --- | --- |
| 1 | Video-game HUD | He calls himself efficient. | ADMIN PRIVILEGES: SELF-AWARDED |
| 2 | Phone notification | She finally silences work. | QUIET HOURS: EXCLUDES YOUR OWN REMINDERS |
| 3 | Bank alert | He accepts an annual subscription. | $14.99/mo × 12 = $179.88/yr; before tax |
| 4 | Medical bill | She wants one clear total. | FICTIONAL BILL: $400.00 + $80.00 = $480.00 |
| 5 | Achievement pop-up | He has made himself indispensable. | DELEGATION LOCKED BY ACCOUNT OWNER |
| 6 | Error dialog | He requests an exception. | REQUESTER ALSO WROTE THE RULE |
| 7 | Receipt | He dismisses a processing charge. | $39.99 + $7.19 handling = $47.18; no tax |
| 8 | Delivery tracker | She orders convenience. | DRIVER ARRIVED; YOUR SHOES HAVE NOT |
| 9 | Calendar invite | He says the issue is resolved. | RECURRING: UNTIL YOU ADMIT OTHERWISE |
| 10 | Email subject | She brags about her new authority. | RE: RE: RE: YOUR APPROVAL REQUIRED |
| 11 | Terms popup | He demands identical treatment. | OWNER EXEMPTION: NOT SELECTED |
| 12 | Loading bar | He automates postponement. | DELAY SUCCESSFULLY EXTENDED |
| 13 | Review stars | She reviews her own policy. | 1/5 STARS; VERIFIED POLICY AUTHOR |
| 14 | Incident report | He calls the failure unexpected. | WITNESS: YOUR PREVIOUS EMAIL |
| 15 | Credit score screen | She announces a confidence boost. | FICTIONAL SCORE: 640 → 640; confidence excluded |
| 16 | Tip screen | He selects an eighteen-percent tip. | $25.00 × 18% = $4.50 tip; food subtotal |
| 17 | Insurance EOB | He assumes the insurer paid everything. | NOT A BILL: $1,000.00 allowed − $800.00 paid = $200.00 share |
| 18 | Payroll panel | She volunteers for covered overtime. | 4 hr × ($20.00 × 1.5) = $120.00 gross |
| 19 | PTO counter | He calls the weekend a reset. | 11 days − 2 approved days = 9 days |
| 20 | HOA notice | She standardizes the fines. | FICTIONAL RULE: 2 items × $25.00 × 4 days = $200.00 |
| 21 | Gym portal | He buys a monthly commitment. | $30.00 × 12 = $360.00; no enrollment fee |
| 22 | BNPL checkout | She celebrates a smaller payment. | $120.00 ÷ 4 = $30.00 each; interest-free terms |
| 23 | Loan calculator | He picks a fictional monthly-interest model. | $1,000.00 × (24% ÷ 12) = $20.00 interest |
| 24 | Severance letter | She trusts the written package. | 2 weeks × $1,000.00/week = $2,000.00 gross |
| 25 | Tax receipt | He forgets the stated fictional tax rate. | $40.00 × 8% = $3.20 tax; total $43.20 |
| 26 | Parking app | She buys one extra hour. | 3 hr × $2.00 = $6.00; fee included |
| 27 | Rental ledger | He disputes his own recorded deduction. | $1,200.00 deposit − $150.00 documented damage = $1,050.00 |
| 28 | COBRA estimate | She discovers the employer contribution. | $700.00 full premium × 102% = $714.00/month |
| 29 | Support queue | He demands the owner. | TRANSFER DESTINATION: YOUR CURRENT CHAIR |
| 30 | Satisfaction survey | She finally escapes the form. | CLOSING THIS SURVEY OPENS A SURVEY |

Do not invent credit-score changes from a single payment: scoring is model-dependent. For cards 18, 24, 25, 27, and 28, establish the relevant fictional employment terms, tax assumption, lawful deduction, or plan assumption; the arithmetic does not establish legal applicability.

## Stupid-face freezes

Use exaggerated fictional adult faces, never a real person's likeness or disability-coded features.

- **Smug squint:** shortcut appears to work; chin slightly raised; 0.3-second freeze.
- **Blank mouth-breather stare:** the rule lands; slack jaw and unfocused pause, without medical or disability labels.
- **Bug-eyed panic:** first major consequence; slow zoom, not frantic camera shaking.
- **Hollow dead-inside face:** the petty consequence registers; minimal movement.

For a selected 0.3-second narration pause, a freeze or slow push can carry the thought; add one soft cue only when it improves that specific gag. An awkward hold may need complete silence. Do not insert a pause after every sentence. Usually two or three face beats per 60 seconds suffice; longer scripts need meaningful progression, not more of the same face.

## SFX and timing

| Cue | Best use |
| --- | --- |
| Error buzz | A precise denial, immediately after its spoken line. |
| Cash register | A confirmed cost, after the amount is fully spoken. |
| Record scratch | One status reversal; use sparingly. |
| Soft startup chime | Cheerfully functioning bureaucracy. |
| Dry stamp / mouse click | A rule becomes official. |
| Sad trombone | Rarely, for a deliberately small indignity. |
| Soft cartoon bonk | Level 3 cutaway only; no realistic injury sound. |
| Silence | Before the main hit and for the 0.5-second double-tap gap. |

Duck music before a punchline; place SFX after it, never on its words. Preserve the full half-second gap between the two hits. Stop speaking during each scheduled freeze. No scream, wet impact, realistic distress, or shock-audio montage.

## Direction in the complete prompt

Use scene IDs and narration paragraph IDs, with exact spoken reveal anchors. Describe the physical action and expression progression rather than only naming a mood. Specify where eyes look, what hands hold, what changes, and which moment is held. Distinguish a scene from its internal shots.

The full output follows production-prompt.md: scene directions, a card inventory, and a sound plan. For an explicitly requested script-only or visual-track edit, the compact `TIME | NARRATION | CARD TEXT | FACE / ANIMATION | SFX` table remains useful. It is not a substitute for the complete production prompt on a new full story. Use "None" when an uncluttered frame or silence serves the joke.
