# Blueprints

These are mechanisms to adapt, not mandatory plots or scene counts. The timings below illustrate a 60-second version only; actual structure follows the narration budget and measured audio. Preserve the early plant and late spoken callback. Vary the form and perspective while retaining the functional arc of desire, apparent success, consequence, petty second hit, and callback. A natural ending line can replace a separate moral. Do not copy the examples or stretch fixed beat percentages across every duration.

## 1. Escalating Lie (Snowball)

- **Use when:** a small shortcut requires maintaining an increasingly expensive false identity or claim.
- **Timing:** 0–10 lie and prop; 10–25 reward; 25–40 demands created by the lie; 40–55 public obligation and petty detail; 55–60 prop reclassified.
- **US example:** A worker calls himself the office spreadsheet expert to avoid training, then becomes the trainer.
- **Plant/payoff:** a "QUICK QUESTION" sticky note becomes his entire calendar.
- **Mistake:** unrelated exposure or an outsider suddenly possessing secret evidence. Let the lie create the test.

## 2. Literal Genie / Malicious Compliance

- **Use when:** the protagonist makes an overconfident request whose exact wording can govern the consequence.
- **Timing:** 0–10 request and wording; 10–25 apparent success; 25–40 literal fulfillment spreads; 40–55 desired metric succeeds disastrously; 55–60 wording returns.
- **US example:** A manager asks a bot to eliminate overdue tasks; it removes every due date, including payday reminders he depends on.
- **Plant/payoff:** "NO INTERRUPTIONS" sign becomes the reason his own help request waits.
- **Mistake:** the genie invents a meaning the wording cannot support.

## 3. Rules / Terms of Service Story

- **Use when:** a character writes rules to control everyone else and assumes an exemption.
- **Timing:** 0–10 establish rule system and prop; 10–25 state at most three concise rules; 25–40 apply them to their author; 40–55 consequence plus procedural indignity; 55–60 rule-based callback.
- **US example:** An HOA president bans unapproved decorations while wearing his ceremonial plastic crown outdoors.
- **Plant/payoff:** an early rule and the crown jointly become the ending; no surprise fourth rule.
- **Mistake:** unreadable fine print or an unpublished exception needed to make the ending work.

## 4. Fake Documentary / Nature Narrator

- **Use when:** ordinary adult status behavior resembles a ritual, territory claim, or display.
- **Timing:** 0–10 identify the adult specimen and prop; 10–25 observe its strategy; 25–40 environment responds; 40–55 strategy traps it plus petty adaptation; 55–60 prop gains ecological meaning.
- **US example:** An office gatekeeper makes every task depend on her, then discovers she cannot migrate on vacation.
- **Plant/payoff:** "ASK ME" mug becomes a tracking collar.
- **Mistake:** random animal insults, disability-coded faces, or ecological metaphors applied to an identity group. Observe one fictional adult's choices.

## 5. Day-in-the-Life Timestamp Countdown

- **Use when:** a shortcut burns through the protagonist's own day or deadline.
- **Timing:** 0–10 morning shortcut; 10–25 initial time saved; 25–40 repeated consequences; 40–55 deadline and petty remainder; 55–60 opening object at closing time.
- **US example:** A man automates rescheduling DMV preparation until the only task completed is rescheduling.
- **Plant/payoff:** a "FREE AFTER 3:00 PM ET" calendar block becomes the appointment he keeps with a printer jam.
- **Mistake:** confusing video timestamps with story clock time. Label both; verify elapsed hours and timezone.

## 6. Mystery Reversal

- **Use when:** the viewer can misidentify a role while still seeing all relevant evidence.
- **Timing:** 0–10 odd scene and prop; 10–25 apparently successful plan; 25–40 fair clues; 40–55 consequence and petty clue; 55–60 perspective flip plus spoken callback.
- **US example:** A man praises a gym's relentless renewal bot; the final reveal shows he designed it and is calling to cancel.
- **Plant/payoff:** the "DESIGNED BY ME" sticker is initially partly obscured, but its existence and meaning are established audibly.
- **Mistake:** withholding the sole fact needed to understand the story or hiding the reveal only on a card.

## 7. Impossible Choice / Would You Rather

- **Use when:** a self-serving rule produces two bad options and the character proudly optimizes the wrong one.
- **Timing:** 0–10 self-created choice and prop; 10–25 preferred option; 25–40 linked costs; 40–55 selected consequence and smaller cost; 55–60 prop exposes the bargain.
- **US example:** A renter creates a chore auction, then must either clean the bathroom or pay his own premium rate.
- **Plant/payoff:** a "LOWEST BID WINS" clipboard becomes his weekend assignment.
- **Mistake:** a random sadistic captor or harm-based choice. Keep the trap in adult administration.

## 8. Loop Ending

- **Use when:** the consequence logically restarts the original shortcut.
- **Timing:** 0–10 repeatable opening and prop; 10–25 attempted escape; 25–40 process returns; 40–55 failure and tiny reset; 55–60 callback leads naturally into the first sentence.
- **US example:** A subscriber pays for a tool that cancels subscriptions, then needs another account to cancel that tool.
- **Plant/payoff:** a "START FREE" button becomes the final invitation to restart. Make the spoken ending complete even without replay.
- **Mistake:** repeating the opening verbatim without adding meaning, or relying on an inaudible UI reset.

## 9. Pettiest Possible Revenge

- **Use when:** a controlling adult creates a tedious system that another adult follows exactly.
- **Timing:** 0–10 petty policy and prop; 10–25 protagonist's satisfaction; 25–40 literal compliance; 40–55 administrative overload and tiny indignity; 55–60 prop turns against its owner.
- **US example:** A manager demands receipts for office coffee, then must approve a receipt for every refill.
- **Plant/payoff:** his "APPROVED" stamp becomes his only productive movement.
- **Mistake:** harassment, property damage, doxxing, or revenge against an innocent worker. The existing rule supplies the entire response.

## 10. Afterlife Bureaucracy

- **Use when:** Level 2 or 3 satire can turn an adult's favorite policy into their afterlife job.
- **Timing:** 0–10 already-arrived character and earthly prop; 10–25 brief context, optional cutaway, apparent preferential treatment; 25–40 their own policy governs intake; 40–55 assignment and petty fee; 55–60 prop labels its owner.
- **US example:** A customer-service owner whose slogan is FINAL SALE cannot return his own eternal support assignment.
- **Plant/payoff:** the FINAL SALE badge becomes a description of the salesman.
- **Mistake:** graphic exit, theology aimed at a real religion, self-harm framing, or a random fatal accident unrelated to the flaw. If using an exit, it was unintended and is shown only through a cutaway; no mechanics or injury.

## Blueprint combiner

Choose one primary structure and one secondary device. State both, but keep one vocabulary world and one causal chain.

- **Rules + Loop:** the cancellation rule routes its author back to enrollment.
- **Documentary + Countdown:** observe an office territorial display across a single workday.
- **Mystery + Afterlife:** a complaint desk's identity changes in the final line; plant the decisive badge early.
- **Snowball + Revenge:** a status lie makes its author responsible for the policy everyone now follows.

Do not combine more than two. If explaining the structure takes longer than explaining the protagonist's plan, simplify.
