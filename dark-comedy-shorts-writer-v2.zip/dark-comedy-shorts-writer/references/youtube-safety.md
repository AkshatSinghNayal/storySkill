# YouTube Safety

Policy review date: 11/25/2026. Guidelines change; the user must verify current advertiser-friendly and Community Guidelines before publishing. Script review cannot guarantee monetization, continued availability, or an age rating. YouTube assesses context across the video and its packaging. [Advertiser-friendly guidelines](https://support.google.com/youtube/answer/6162278)

## Operational checklist

- Apply every ban in [adult-content-and-violence.md](adult-content-and-violence.md). A cutaway does not automatically make a violent premise acceptable. [Violent or graphic content policy](https://support.google.com/youtube/answer/2802008)
- Apply this skill's conservative opening-word rule from [voice-and-metaphors.md](voice-and-metaphors.md). It is an editorial preference, not a published keyword blacklist. Euphemisms do not change content classification.
- Write original scripts. Do not copy viral videos, imitate a real creator's voice, or merely replace names in these examples. Vary causal mechanisms, visuals, settings, and delivery across the channel. Original wording alone does not resolve repetitive or mass-produced-content concerns. [Channel monetization policies](https://support.google.com/youtube/answer/1311392)
- Use generic private-company categories, invented UI, and fictional adults. No allegations about real brands or executives.
- Make fictional bills and legal documents visibly fictional. Do not present invented fees, tax rates, medical rules, or legal rights as verified facts.
- Use cleared or original music, images, voices, and SFX. Assess any disclosure requirements for realistic altered or synthetic media under [YouTube's disclosure guidance](https://support.google.com/youtube/answer/14328491).

## Titles, descriptions, tags

Every title: maximum eight words, premise-first, accurate, and free of the restricted opening words. Example: "He Charged Himself a Convenience Fee."

Description example: "Original fictional comedy about a man trapped by his own refund policy. All characters, interfaces, fees, and documents are invented."

Suggested tags: "dark comedy," "original comedy," "workplace satire," "fictional story," "faceless shorts." Choose only relevant tags. Do not use tragedy keywords, unrelated trends, or real-brand names for reach.

## Pre-publish

- Watch the full rendered video, including thumbnail, cards, music, sound, and description; check the first five seconds separately.
- Verify numbers and any real-world rules again; confirm all fictional notices are legible.
- Check phone readability, audible callback, pause timing, captions, and rights to assets.
- Review advertiser suitability separately from removal risk; assess audience designation honestly and avoid packaging adult satire as children's content.
- Check current policies and complete applicable platform disclosures accurately. If a beat is borderline, rewrite it; do not promise an upload outcome.
