# Faceless Shorts Integration

This is a compatibility guide based on the faceless-shorts archive reviewed in this workspace on November 26, 2026. It is not a claim that another computer has the identical version. The receiving agent should inspect the installed files. A writing-only session need not install or execute the renderer to produce a useful prompt.

## Visual types and ownership

| Style | Actual visual system | Fit |
| --- | --- | --- |
| Tall Tale | 2D camera-facing cartoon cutouts in real Three.js sets | Default for expressive adult fictional comedy; explicitly override the example's true-story-only convention. |
| Stick Story | 2D stick figures and illustrated rooms | A deliberately simpler graphic look, if selected. |
| Inside Out | 2D illustration and x-ray cutaways | Explainer look, not a general default for relationship satire. |
| Paper Atlas | 2D paper illustration and maps | Historical/storybook look. |
| Deep Dive | Modeled 3D people and environments | Actual 3D characters; adapting it to a comedy requires specific acting/set work. |
| Night File | Dark 3D environments and faceless people | Mystery staging, usually a poor match for expressive comedy. |

Do not promise modeled 3D humans from the Tall Tale cutout system. If the user explicitly asks for fully 3D characters, choose/adapt a true 3D engine and specify the needed expressions; do not quietly label a flat substitute "3D." A source example's 40–60-second story is a format convention, not evidence of a hard engine duration limit. Longer stories still need realistic speech/render budgets.

The approved story controls narration, causality, callback, story duration, and card text. The chosen visual style controls character construction, palette, and caption rendering unless the brief declares an override. Do not let the generic x-ray/yellow-caption QA rules overwrite Tall Tale's white short captions. Fictional adult satire does not need fabricated factual sources; list sources only for real claims requiring verification and retain the fictional labeling.

## Existing pipeline

The reviewed archive has `scripts/new_video.sh`, `voice.py`, `words.py`, `estimate.py`, and style example projects. Project tools include `tools/capture.mjs`, `tools/mix.py`, `src/shots.js`, and shared style components under `src/core/`.

| Artifact/API | Expected contract |
| --- | --- |
| `script.json` | Title, voice, global speed, lead/outro/gap, music, sources, and `lines` with spoken `text`, optional `caps`, and `gap`. New properties require code that consumes them. |
| `data/narration.wav` | Final narration used by alignment and mixing. |
| `data/lines.json` | Object with `duration` and `lines`: `{i, text, start, end}`. |
| `data/words.json` | Array of `{w, line, s, e}`; `line` refers to the renderer line index. |
| `src/core/timing.js` | `L(i)`/`Le(i)` read line times. `Wd(word, line)` returns the first prefix-matching word; it does not accept an occurrence index in the reviewed API. |
| `src/shots.js` | Per-video shots and sound cues; tied to actual timing. |
| `data/cues.json` → `tools/mix.py` | Procedural cues plus narration/music produce `data/mix.wav`. |
| `tools/capture.mjs` | `check`, `cues`, `frames`, `sheet`, `video`, `preview`. |

The prompt's N001 paragraph IDs are a planning/voice layer, not native renderer indices. Maintain a mapping when one paragraph spans several cuts. A new `narration_timeline.json` alone will not update the existing engine. Produce the original timing files as well; use short unambiguous anchors or explicit aligned word indices for repeated words. Do not call an invented `Wd` overload.

## Voice and timing limitations

- The reviewed wrapper uses `kokoro-onnx` and passes `en-us`/`en-gb`. Do not blindly copy the `a` language identifier from a different Kokoro interface. Validate the actual installed signature.
- `am_michael` is the preferred reviewed voice. Alternative voices must exist in the installed model's inventory, not merely in an online list.
- The original voice script reads one global speed. A delivery table does not implement per-paragraph speed by itself. A small segment-synthesis adapter may apply individual speeds, concatenate audio, and export compatible timing. Otherwise disclose the use of one global speed; do not claim the requested variations occurred.
- Whole-sentence synthesis preserves flow. Do not make every caption its own TTS call. Account for existing silence before adding a requested pause and normalize joins without chopping consonants.
- The original sentence-internal cut placement uses estimated durations and nearby pauses. Its fallback word timing is interpolation, not measured synchronization. Prefer reliable alignment and measured segment boundaries; validate rather than relabel estimates as exact.
- `words.py` can infer scripted words even when recognition misses them. Check matching quality and inspect suspicious words. Zero/negative spans or a poor match require correction or clearly labeled phrase-level fallback.
- Captions-only is an explicit audio mode. `estimate.py` does not remove a previous narration file, and the original mixer includes that file if present. Use an isolated project or make the mixer obey the selected voiceover mode so stale speech is not reused.

## Tall Tale implementation fit

`Toon` supports moods such as neutral, smug, shock, worried, angry, sad, sly, proud, tired, and dizzy, plus look direction, blink, tears/sweat, arm poses, and walking/sitting states. Compose an exhausted stare or delayed realization from these controls; do not assume a named `dead_inside` preset exists. Keep character props attached to their hands. Reuse interiors/world pieces with modern apartment or office dressing where suitable. Hoodie silhouettes, unusual hair, appliances, graphs, and specific new sounds may need small extensions.

Tall Tale's caption code removes `*` markers rather than rendering a yellow word. Default to white short captions and reserve yellow for cards. If yellow speech highlighting is explicitly requested, instruct a small caption-renderer change; putting asterisks in `caps` alone is insufficient.

## Practical QA safeguards

Include only the relevant safeguards in each production prompt; do not turn every video into an unrelated engine rewrite.

- In the reviewed capture code, `check` can print `CHECK FAILED` but exit with status 0; this was reproduced. Treat a failure message as a failure and propagate nonzero status when adapting the tool. The export path also needs explicit FFmpeg exit/output checks.
- Verify the MP4 is nonempty and decodable and has the intended streams, resolution, frame rate, and duration. The renderer printing a filename does not prove success.
- Use a stored seed for procedural randomness and time-driven animation so the inspected preview matches the final render. Some reviewed 3D sets use unseeded `Math.random()`.
- A contact sheet samples time; it does not prove every frame was inspected. Inspect transitions and punchline frames at full size and watch/listen to the complete final output before claiming full audiovisual QA. If the environment cannot play audio/video, report that limitation.
- The original self-test deletes its fixed `_selftest` directory. Prefer isolated temporary/project diagnostics; do not run cleanup over a user's existing project.
- Run a short representative sample and measure local throughput before estimating the full render. Software-rendered 3D can be slow; a timed-out sample is an unresolved diagnostic, not proof the style cannot work.
- The original six capture scripts are copies. Prefer project-local fixes for the requested film; do not claim to have updated all installed styles when only one copy changed.
- Publishing instructions in the archive name environment-specific Zapier tools and public staging hosts. They are not universally available. Metadata/cover creation does not authorize hosting or channel writes. Discover the actual available integration only when publishing is requested.

The prior review passed syntax checks and one Inside Out browser check. It did not validate a complete Kokoro-to-MP4 run; a Tall Tale sample did not finish within a 90-second bound on that machine. Do not present that review as an end-to-end certification of the installed pipeline.
