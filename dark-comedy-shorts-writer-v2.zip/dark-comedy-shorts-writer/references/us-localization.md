# US Localization

## A. Formatting and voice

The audience is United States adults unless the user explicitly overrides it. In US stories, use only dollars: $1,234.56, with comma thousands, period decimals, and $ before the amount. Use two decimals on cards and math tables; say "about twelve hundred dollars" when precision adds nothing. No other currencies, lakh/crore grouping, or unconverted foreign prices.

Dates: month/day/year, such as 03/15/2026. Times: 3:00 PM ET, using 12-hour time, AM/PM, and ET, CT, MT, or PT as appropriate. ET/PT avoid careless daylight-saving abbreviations. Temperature: Fahrenheit. Distance: miles. Weight: pounds. Height: feet and inches, such as 5 ft 10 in. Story dates and clock times must agree with the chronology.

Use American English: color, organize, mom, apartment, trash, elevator, cell phone, sidewalk, fall. Voice: dry, tired millennial/Gen Z; "per my last email," "circle back," "PTO," "at-will," "side hustle," "doom-scrolling." "Venmo me" is familiar slang; prefer "send me your share" in a brand-free script. Do not make an accent or background the joke.

## B. US money matrix

These are broad **fiction-writing ranges**, not national averages, quotes, legal entitlements, or financial advice. Choose a coherent household, city tier, job, and plan. Do not combine a low-cost rent with luxury-city expenses without explanation. Verify a real jurisdiction or current policy when the plot depends on it. Reference check date: 11/25/2026.

| Category | Plausible story inputs | Constraint |
| --- | --- | --- |
| Federal wage floor | $7.25/hour | Federal floor for covered workers; state/local minimums may be higher. Do not use this as the universal market wage. |
| Entry-level hourly work | $15.00–$25.00/hour | Select a job and location; lower/higher pay can exist. |
| Retail annual gross | $31,200.00–$49,920.00 | Assumes $15.00–$24.00/hour × 40 hours × 52 weeks, no unpaid weeks. |
| Office support annual gross | $35,000.00–$60,000.00 | Fictional full-time assistant, scheduler, or support role; benefits separate. |
| Office specialist annual gross | $50,000.00–$85,000.00 | Fictional coordinator, analyst, or experienced specialist; location matters. |
| Gig receipts | $15.00–$30.00/hour gross; $15,000.00–$60,000.00/year at 1,000–2,000 billable hours | Expenses, unpaid waiting, and taxes reduce take-home; endpoints depend on hours. |
| Overtime | 1.5 × regular rate for covered nonexempt work over 40 hours/week | Salaried does not automatically mean exempt; state rules may add requirements. |
| PTO | 10–20 days/year; 11 is a useful precise fictional choice | Employer policy and applicable leave laws vary; no universal paid-vacation entitlement. |
| 401(k) match | Illustrative 3%–6% of eligible pay | State the formula; "50% of contributions up to 6% of pay" yields at most 3% of pay. Vesting varies. |
| Severance | $0.00 if none; fictional offers often 1–2 weeks' pay per year of service | A possible package, not a nationwide requirement; use actual contract terms if real. |
| Unemployment | Illustrative $100.00–$600.00/week for an eligible fictional claimant | State amounts, eligibility, duration, and higher caps vary; not automatic after firing. |
| Employment status | W-2 employee; 1099 independent contractor | Classification follows the working relationship and law, not a checkbox. At-will has legal exceptions; it does not permit unlawful discrimination or retaliation. |
| Lower-cost-city rent | $800.00–$1,400.00/month | Modest apartment, not a national average. |
| Mid-cost-metro rent | $1,300.00–$2,200.00/month | Specify apartment size if important. |
| High-cost-metro rent | $2,200.00–$4,000.00/month | Modest-to-comfortable apartment; neighborhood matters. |
| Security deposit | Often 1–2 months' rent where lawful | Some jurisdictions cap it lower or have specific exceptions; do not assert two months universally. |
| Rent late fee | $25.00–$100.00 as a fictional flat charge | Lease and local law must permit it; grace periods/caps vary. |
| HOA dues | $100.00–$500.00/month | Amenity-heavy properties can be higher; invented fines require an explicit fictional rule. |
| Utilities | $100.00–$300.00/month | State whether internet is included; season and apartment size matter. |
| Renter's insurance | $10.00–$30.00/month | Coverage and deductible vary. |
| Lease-break charge | 1–2 months' rent in a specified fictional lease | Other duties and tenant protections may apply; not a universal right to exit. |
| Student loan balance | $15,000.00–$60,000.00 | Higher balances exist; use an individual fictional borrower. |
| Student loan payment | $150.00–$650.00/month | Select a matching balance, rate, and term; repayment programs change. Do not infer a payment from balance alone. |
| Credit card balance/APR | $1,000.00–$10,000.00; illustrative 20%–25% APR | 23.99% is plausible, not a guaranteed current rate or a cap. |
| Card minimum payment | Illustrative $25.00–$40.00 floor or 1%–3% of balance plus specified interest/fees | Use one disclosed issuer formula; a minimum can barely reduce principal. |
| FICO score | Standard base range 300–850 | Some specialized models differ. Never invent a deterministic points-per-payment rule. |
| Overdraft fee | $0.00–$35.00 per eligible event; about $35.00 for a fee-charging fictional bank | Some banks charge none; terms, opt-in requirements, and law matter. |
| BNPL | $40.00–$400.00 purchase split into four payments | Only call it interest-free when that is a stated term; other products charge interest. |
| Car payment | $300.00–$900.00/month | Use matching principal, APR, and term if showing amortization. |
| Employee health premium | $100.00–$350.00/month for fictional individual payroll share | Employer contribution is separate; family coverage differs. |
| Unsubsidized individual premium | $400.00–$1,000.00/month | Age, location, plan, and subsidies strongly affect the actual price. |
| Individual deductible | $500.00–$5,000.00/year | Deductible is not the premium or the out-of-pocket maximum. |
| Copay | $20.00–$75.00 for a fictional covered visit | Preventive care and other services may follow different terms. |
| Out-of-pocket maximum | Fictional plan choice $4,000.00–$10,000.00/year for an individual | Check current plan-year limits. For 2026 Marketplace plans, the individual ceiling is $10,600.00; premiums and noncovered spending are excluded. |
| ER billed charge | $1,000.00–$5,000.00 for a fictional uncomplicated visit | Billed charge, allowed amount, and patient responsibility are different. Major care can be much higher. |
| Ground ambulance billed charge | $500.00–$2,500.00 | Actual bills and protections vary; do not equate the charge with the patient's final share. |
| Prior authorization | A plan approval step, no universal price | Do not invent a standard "authorization fee" as a factual US rule. |
| COBRA | Illustrative $500.00–$1,200.00/month individual total premium | Often up to 102% of the full plan cost, not 102% of the former employee share; exceptions exist. |
| Gas | $3.00–$5.00/gallon | Plausible fictional range; verify place and date for a real setting. |
| Groceries | $60.00–$120.00/week for one fictional adult | Diet, location, and household scale matter. |
| Delivery apps | $3.00–$10.00 disclosed fees plus a 15%–20% tip assumption | Distinguish food, fees, tax, and tip; a fee is not the driver's tip. |
| Subscriptions | $5.99–$19.99/month | State billed cadence and tax treatment; annual plans can differ. |
| Gym | $10.00–$80.00/month; $0.00–$100.00 disclosed enrollment/annual fee | Cancellation terms and state law vary; invented traps must be clearly fictional. |
| Parking ticket | $25.00–$100.00 for an ordinary fictional violation | Not a quote for a named city; late penalties need stated rules. |
| DMV costs | $20.00–$80.00 license renewal; $50.00–$250.00 registration illustration | State, vehicle, term, and extra taxes matter. |
| Sales tax | Use a declared fictional combined rate such as 6%–10%, or verify the actual location | State and local rates and exemptions differ. Some states have no general statewide sales tax; do not say every purchase is taxed. |
| Tipping | 15%, 18%, or 20% of a stated base | A narrative assumption, not a law; specify pre-tax food subtotal when used. |

Use "about" in narration when exactness does not improve the joke. Keep full precision in the math check. Tell the user: "Verify current numbers and rules before publishing; prices, benefits, fees, and laws change."

### Reality anchors and policy cautions

- Check federal minimum wage and overtime against the [Department of Labor](https://www.dol.gov/agencies/whd/flsa/faq). Check occupation and location using [BLS wage data](https://www.bls.gov/ooh/sales/retail-sales-workers.htm); the matrix is an editorial planning tool, not a quotation of BLS averages.
- Confirm plan-year out-of-pocket limits with [HealthCare.gov](https://www.healthcare.gov/glossary/out-of-pocket-maximum-limit/) and continuation-coverage assumptions with [DOL's COBRA guide](https://www.dol.gov/agencies/ebsa/about-ebsa/our-activities/resource-center/publications/workers-guide-health-benefits-cobra).
- Many emergency and certain in-network-facility surprise bills have federal protections; ground ambulance generally falls outside those federal protections, though state protections may apply. Do not imply every out-of-network demand is legally owed. [CMS billing-rights guidance](https://www.cms.gov/initiatives/your-patient-rights/medical-bill-rights/know-your-rights/insurance)

## C. Math rules

Before drafting and again before output, list **every** number appearing in narration or cards: dollar amounts, rates, quantities, time periods, scores, dates, and units. A direct fictional input is valid: label its formula "given fictional price," not "verified market fact." For noncomputed items use "identifier," "stated count," or "scheduled time." If no justification exists, replace the number.

Use decimal arithmetic or integer cents when a calculator is available. Never claim a calculator check you did not perform. Round monetary outputs to cents at the stated billing step; retain precision until then. Reconcile the final ledger: beginning balance + charges + interest − payments = ending balance. Keep gross pay distinct from take-home.

| Calculation | Correct example and limitation |
| --- | --- |
| Annual subscription | $14.99 × 12 = $179.88 before tax. |
| Monthly interest illustration | $1,000.00 × (24% ÷ 12) = $20.00 for a stipulated monthly model. |
| Precise APR illustration | $2,000.00 × (23.99% ÷ 12) = $39.9833… → $39.98; monthly approximation. |
| Minimum payment | $45.00 − $39.98 interest = $5.02 principal reduction, assuming no new purchases/fees. |
| Monthly compounding | $1,000.00 × (1 + 0.24/12)^12 = $1,268.24 after final rounding; no payments or fees, monthly model. |
| Severance | 2 weeks/year × 3 years × $1,000.00/week = $6,000.00 gross under the fictional agreement. |
| Tip | $30.00 × 15% = $4.50; × 18% = $5.40; × 20% = $6.00. |
| Tip and tax total | $30.00 food + $2.40 tax at 8% + $6.00 tip at 20% of food = $38.40. |
| Exact odd fee | $39.99 base + $7.19 disclosed handling = $47.18; no invented unexplained precision. |
| Loan payment | Payment = P × r / (1 − (1 + r)^−n), with monthly r = APR/12 and n monthly payments; disclose fees separately. |

APR/12 is a **monthly rate**, not a dollar amount and not a universally exact credit-card billing method. Real cards often use daily periodic rates and average daily balances; use the actual agreement if recreating a real bill. [CFPB interest calculation guidance](https://www.consumerfinance.gov/ask-cfpb/how-does-my-credit-card-company-calculate-the-amount-of-interest-i-owe-en-51/)

Mandatory output: `figure | formula | result`. Include base inputs and totals, not just the final calculation. Show the math on the actual card when arithmetic is the joke. For humorous impossible prices, label the premise "INTENTIONAL ABSURDITY — FICTIONAL" and keep the calculation correct. Supernatural administration may be impossible; its arithmetic must not be.

## D. US name matrix

Always give the protagonist a first name. Add a last name for a card, email, or legal-looking document. These pools are casting options, not demographic rules or claims about who can have a name.

| Pool | Names |
| --- | --- |
| Gen X / older | Mike, Karen, Greg, Linda, Brian, Dave, Susan, Todd |
| Millennials | Tyler, Brittany, Kyle, Ashley, Josh, Megan, Chad, Jessica, Derek, Amanda |
| Gen Z / younger adults | Jayden, Madison, Mason, Ava, Logan, Chloe, Austin, Kayla, Tristan, Maya |
| Additional American backgrounds | Marcus, Priya, Luis, Mei, Jamal, Sofia, Andre, Hannah, Omar, Elena, Kevin, Tanya |
| Surnames | Miller, Johnson, Garcia, Nguyen, Patel, Brooks, Carter, Kim, Rivera, Walker, Sullivan, Washington, Chen, Foster, Reyes |

Rotate naturally and evenly across a series. Avoid the same first name in consecutive unrelated stories; honor a user-specified name or an intentional recurring cast. Use Karen sparingly; avoid stale Karen/Chad name jokes unless meaningfully subverted. Do not derive identity from a name or connect stupidity, flaw, or punishment to race, ethnicity, religion, nationality, gender, or another group. No real celebrities or identifiable private people.

Side characters usually receive roles: the boss, HR, the landlord, the bot, the claims adjuster. Give every rendered recurring character a distinct production ID even when unnamed in narration. State who narrates and who drives the flaw; do not introduce an extra actor through ambiguous possessives. Do not overcrowd a short script with names. If prior history is unavailable, state that the rotation baseline is unknown rather than inventing a previous protagonist.

## E. Institutions and settings

Use generic private-company categories: budget airline, meal-kit startup, big-box store, health insurer, student loan servicer, HOA, rideshare app, streaming service, gym chain, dealership. Do not name real executives or defame real companies. Government/system references may include IRS, DMV, Social Security, FAFSA, Medicare, jury duty, and small claims court; fictional notices must not impersonate official documents or invent real legal rights.

Twenty-five reliable adult settings:

1. Surprise medical bills.
2. HOA fines.
3. Gym cancellation.
4. Student loans.
5. Rent hikes.
6. Security deposits.
7. At-will firing.
8. Return-to-office mandates.
9. Side hustles.
10. Crypto and meme-stock regret.
11. BNPL.
12. Tipping screens.
13. Subscription traps.
14. Jury duty.
15. DMV waits.
16. Warranty calls.
17. Open enrollment.
18. PTO denial.
19. Self-checkout.
20. Group-chat rent splitting.
21. Deductibles.
22. Car dealership financing.
23. Venmo-style payment requests, shown with generic UI.
24. Landlord repairs.
25. Parking apps.

For a user-requested non-US adaptation, explicitly replace currency, institutions, units, spelling, and names together. Never accidentally blend two locales.
