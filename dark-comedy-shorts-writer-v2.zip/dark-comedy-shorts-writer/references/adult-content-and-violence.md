# Adult Content and Violence

## Intensity dial

| Level | Supported treatment |
| --- | --- |
| 1 — Mild | Embarrassment, debt, firing, social ruin, and petty adult inconvenience. |
| 2 — Dark, DEFAULT | May include implied death, hospital context, afterlife bureaucracy, or cartoon consequences; these are ceilings, not required ingredients. |
| 3 — Black | May include implied or offscreen violence, grim irony, mortality, money, work cruelty, divorce, compulsive app use, and ego. Keep violent material brief and incidental. |
| 4 — Extreme | NOT SUPPORTED. Say: "Level 4 is outside this skill; I can write a Level 3 version with implied consequences and no graphic detail." Then provide the permitted adaptation when the premise allows it. |

"Adult" means adult situations and cynicism, not shock for its own sake. Non-explicit dating, infidelity, breakups, selfish partners, and roommate conflicts are allowed story contexts; do not turn them into sexual scenes or claims about a gender. Financial anxiety is setting; chosen selfishness or overconfidence creates the comic consequence. Do not suggest real victims deserve harm.

## Allowed techniques within the chosen level

- Cut away before impact. Return to a form, waiting room, or obviously imaginary afterlife desk.
- Use impossible cartoon physics, such as a paper-flat silhouette reinflating, without anatomy or injury detail.
- At Level 3, imply a brief offscreen mishap with black screen, a soft nonrealistic effect, then a deadpan administrative line. No suffering audio.
- Turn mortality into invoices, claims, or performance reviews. A deceased character is already beyond the event; the joke is their continued commitment to a foolish policy.
- If an exit is part of the plot, it is unintended, causally related to the adult protagonist's flaw, and contains no replicable mechanics. Never frame intentional self-destruction as an efficiency hack.

## Hard bans at every level

No gore, blood, graphic or lingering injury detail; suicide or self-harm as plot or punchline; sexual violence or sexual content; violence against children or animals; firearms violence; school or mass-casualty references; real people, real tragedies, or real victims; hate or targeting based on race, religion, gender, nationality, disability, sexual orientation, or any identity group; instructions or glorification of harming others; anything functioning as a how-to.

Do not evade a ban through synonyms, a black screen, a fictional disclaimer, or an offscreen sound. Cutaway is a presentation technique, not permission to use a banned premise. No dangerous mechanism, dosage, bypass sequence, or stunt instructions.

## Review questions

1. Is every character fictional and every targeted person an adult whose choices create the trap?
2. Is the cruelty aimed at the individual's flaw, never a demographic identity?
3. Is every violent beat implied, cut away, or unmistakably cartoonish and within the chosen level?
4. Could the story plausibly remain on YouTube with at most an age restriction rather than removal? This is only an initial screen.
5. Does the separate advertiser-suitability review pass? Age restriction is not a monetization pass. If dependable advertiser suitability is the priority, reduce a risky Level 3 beat to paperwork or nonviolent embarrassment.

Consult [youtube-safety.md](youtube-safety.md) for current-policy review. Do not certify that any script is guaranteed to monetize.
