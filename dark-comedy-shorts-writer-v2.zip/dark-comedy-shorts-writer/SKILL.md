---
name: dark-comedy-shorts-writer
description: Creates original adult dark-comedy stories and complete, copy-ready production prompts for the faceless-shorts video skill or Antigravity. Use for a new faceless comedy Short, funny narrated story, detailed video prompt, script rewrite, or roast-card visual track. Complete stories include narration, scene direction, voice timing, characters, captions, sound, thumbnail, and export instructions; explicit ideas-only and narrow edits stay scoped.
---

# Dark Comedy Shorts Writer

## Outcome

Turn an adult's specific, selfish shortcut into an original, funny, causally satisfying animated story. **For every complete story, deliver one fully expanded production prompt that can be pasted into another agent without this chat.** A script table, outline, or generic instruction to "make it funny" is not a complete deliverable.

The default audience is US adults and international English speakers who understand American settings. The humor is dry, observant, absurd, and aimed at choices: relationships, roommates, work, social status, convenience, money, and everyday self-deception. Dark does not require death, shock, or cruelty toward an innocent person. Optimize for a clear opening, fresh surprises, and a satisfying payoff; never promise virality, monetization, or a particular retention rate.

This skill writes the production handoff. It does not render, install tools, spend credits, or publish unless the user also requests those actions. The production prompt may direct the receiving video agent to render and verify the complete video.

## Defaults and scope

| Decision | Default |
| --- | --- |
| Output | One complete production prompt for one finished story; no approval round between script and prompt. |
| Topic | Choose a fresh fictional adult situation when unspecified. |
| Duration | Plan around 75–90 seconds; use 45–179 seconds when the story earns it. Honor an explicit target. Count words and pauses before choosing a duration. |
| Narration | One American English male narrator, preferably Kokoro `am_michael`, including quoted dialogue; no separate character voices or required lip-sync. Honor voice overrides. |
| Point of view | Choose first-person participant, third-person deadpan, or documentary to suit this story. Never confuse the narrator with the person whose flaw drives the consequence. |
| Visual style | Tall Tale: expressive **2D cutout characters in 3D sets**. State this accurately. Fully modeled 3D people are a different requirement, not a synonym. |
| Intensity | Level 2 under the content guide; ordinary adult embarrassment often works best. |
| Setting | Fictional adults and generic businesses; US language and units unless overridden. |

Do not ask for optional details that these defaults resolve. Ask only for genuinely missing essentials, such as a script the user wants preserved but has not supplied. Explicit requests for ideas only, a shorter answer, one scene, or a narrow rewrite override the full-prompt default. For "another story," deliver another complete prompt, not merely more premises.

Preserve an explicitly locked user script. Identify a real conflict between exact wording, runtime, or production requirements instead of silently cutting words. For original stories, finish creative revisions before locking the narration in the handoff. A visual-only edit does not authorize rewriting approved narration; propose any necessary spoken repair separately.

## Story principles

1. **A choice causes the trap.** Establish what the flawed adult wants, the shortcut, why it appears to work, and how that same mechanism produces the consequence. An observer narrator or another innocent character may escape or win. Do not punish poverty, illness, identity, or random bad luck.
2. **Plant an audible detail early and repay it in the final spoken line.** Aim to plant within the first 10 seconds and return it within the final 10. The final line changes its meaning; a generic "moral of the story" afterward weakens the ending. Recheck these windows against measured audio during production.
3. **Earn the double-tap.** Main consequence, a deliberate roughly half-second silence, then a smaller, more specific indignity caused by the same setup. The final callback can also be that smaller hit. Stop after it lands.
4. **Make the narrator understandable without the visuals.** Dialogue, the reveal, and the final hit are spoken. Cards supply a separate joke; they do not rescue missing story logic.
5. **Use a coherent figurative vocabulary.** Choose a world appropriate to the premise, without forcing every sentence into jargon. Literal objects or ordinary speech are not a second metaphor world. Familiar formats are tools, not jokes by themselves.
6. **Vary the mechanism, not just the names.** Compare available history, select distinct premises, and avoid repeating the same fee, denial, form, or employment twist in a different costume. Follow the freshness pass in the comedy engine.
7. **Keep numbers and characterization coherent.** Follow localization and content guides. All spoken/displayed amounts reconcile. Targets are specific fictional adults' conduct, never a demographic group.

## Workflow

Read these before a complete story: [comedy engine](references/comedy-engine.md), [voice](references/voice-and-metaphors.md), [blueprints](references/blueprints.md), [visual direction](references/visual-cards-and-faces.md), [localization](references/us-localization.md), [content](references/adult-content-and-violence.md), [publishing context](references/youtube-safety.md), [production prompt contract](references/production-prompt.md), [faceless compatibility](references/faceless-compatibility.md), and [quality checklist](references/quality-checklist.md). For a narrow edit, read the affected references and check downstream dependencies. Craft examples are calibration, not scripts to recycle.

1. **Choose the comic mechanism.** When the premise is open, privately compare three materially different premises. Favor a clear adult desire, an ingenious bad shortcut, a visual opportunity, and a surprising but reconstructable ending. When a premise is supplied, develop it instead of replacing it with unrelated ideas.
2. **Design backward from the final line.** Select the plant, reinterpretation, main consequence, and petty second hit. Write a causal logline identifying the flawed actor: "They did X, so Y followed because Z." Pronouns may change; causal clarity matters more than a stock sentence.
3. **Choose form and perspective.** Use one primary blueprint, optionally one compatible secondary device. The functional arc is desire → apparent success → escalating consequence → double-tap → callback. It need not have five equal scenes or identical timestamps. A cold open or modest earned win is allowed when its causal setup remains clear.
4. **Write and perform the narration mentally.** Use connected conversational prose, specific observations, and selective short punchlines. Draft several final-line alternatives internally and keep the strongest earned callback. Remove jokes that repeat the same information. Do not manufacture a separate moral after the actual ending.
5. **Budget the spoken runtime.** Count only performed narration, with numbers spelled out. Account once for every intentional silence, lead, tail, and added reaction hold. Use the timing method in the production contract; do not invent measured timestamps before audio exists. Revise an original script rather than relying on rushed delivery.
6. **Direct the film.** Establish cast identities, recurring props, shot coverage of all narration, exact reveal anchors, gesture and expression changes, readable card holds, and a restrained sound plan. Stable expressions and prop handling take priority over excessive camera motion.
7. **Build the complete handoff.** Follow all sections in the production contract. Include one canonical narration block, a delivery manifest for every paragraph, and a scene-to-segment map. Embed every required story detail; do not tell the receiving agent to find it in this chat.
8. **Review before delivery.** Run the quality checklist, resolve contradictions, and revise weak jokes. When tools are available, run `scripts/audit_prompt.py` on the draft to check narration, manifest coverage, and the timing estimate. This is a structural aid, not proof of comic quality or actual speech timing.

## Output contract

Start with one concise sentence identifying the title, intended duration range, and visual type. Then give **one copyable `text` code block containing the entire production prompt**, following [production-prompt.md](references/production-prompt.md). No nested code fences inside that block. All 15 sections are completed with story-specific decisions. No placeholders, "same as above," "continue similarly," hidden dependence on another response, or promise to supply the rest later.

Put the exact narration in its designated block once. Production sections refer to paragraph IDs and short trigger quotes, not a second full performance script. Deliver one final spoken callback, not a repeated moral that the renderer might synthesize twice.

After the prompt, provide a short audit: spoken word count, total planned inserted silence, estimated runtime range and assumptions, exact final callback, unresolved real constraints if any, and one freshness fingerprint. Do not dump rejected drafts or inflate an editorial score into evidence. If tools/audio were not used, say the corresponding checks are estimated or unperformed.

Do not save generated story files unless requested. Use available chat history for rotation; when unavailable, say "rotation baseline unknown." Track the last few stories' setting, flawed desire, causal mechanism, perspective, vocabulary world, callback prop, and ending mechanism. An explicitly requested sequel or recurring character takes precedence over name rotation. Never claim global uniqueness or invisible persistent memory.

## Supporting files

| Resource | Use |
| --- | --- |
| [Production prompt](references/production-prompt.md) | Required full output structure, segmentation, timing, detailed scene direction, and deliverables. |
| [Faceless compatibility](references/faceless-compatibility.md) | Renderer contracts, accurate 2D/3D terminology, voice/timing adapters, and observed failure modes. |
| [Comedy engine](references/comedy-engine.md) / [blueprints](references/blueprints.md) | Premise invention, causality, surprise, variation, and callback. |
| [Voice](references/voice-and-metaphors.md) / [visual direction](references/visual-cards-and-faces.md) | Narration, additive cards, acting, audio space, and mobile readability. |
| [Localization](references/us-localization.md) | US setting, names, math, and fictional versus factual inputs. |
| [Content](references/adult-content-and-violence.md) / [publishing context](references/youtube-safety.md) | Category boundaries and responsible fictional packaging. |
| [Quality checklist](references/quality-checklist.md) | Creative and production handoff gates. |
| [Complete production example](examples/example-05-complete-production-prompt.md) | One fully expanded handoff; never reuse its story as a default. |
| [Craft examples](examples/example-01-generic-vs-sharp.md) | Examples 01–04 compare weak and sharper writing; they are not the new full-output format. |
